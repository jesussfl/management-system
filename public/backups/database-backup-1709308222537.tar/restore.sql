--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.5
-- Dumped by pg_dump version 16.1 (Debian 16.1-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE ceserlodai;
--
-- Name: ceserlodai; Type: DATABASE; Schema: -; Owner: ceserlodai_user
--

CREATE DATABASE ceserlodai WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF8';


ALTER DATABASE ceserlodai OWNER TO ceserlodai_user;

\connect ceserlodai

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ceserlodai; Type: DATABASE PROPERTIES; Schema: -; Owner: ceserlodai_user
--

ALTER DATABASE ceserlodai SET "TimeZone" TO 'utc';


\connect ceserlodai

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: ceserlodai_user
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO ceserlodai_user;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: ceserlodai_user
--

COMMENT ON SCHEMA public IS '';


--
-- Name: Medidas; Type: TYPE; Schema: public; Owner: ceserlodai_user
--

CREATE TYPE public."Medidas" AS ENUM (
    'LITROS',
    'KILOGRAMOS',
    'GRAMOS'
);


ALTER TYPE public."Medidas" OWNER TO ceserlodai_user;

--
-- Name: RenglonStates; Type: TYPE; Schema: public; Owner: ceserlodai_user
--

CREATE TYPE public."RenglonStates" AS ENUM (
    'Activo',
    'Eliminado',
    'En Borrador',
    'Deshabilitado'
);


ALTER TYPE public."RenglonStates" OWNER TO ceserlodai_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Account; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public."Account" (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    provider text NOT NULL,
    "providerAccountId" text NOT NULL,
    refresh_token text,
    access_token text,
    expires_at integer,
    token_type text,
    scope text,
    id_token text,
    session_state text
);


ALTER TABLE public."Account" OWNER TO ceserlodai_user;

--
-- Name: Categoria; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public."Categoria" (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text NOT NULL
);


ALTER TABLE public."Categoria" OWNER TO ceserlodai_user;

--
-- Name: Categoria_id_seq; Type: SEQUENCE; Schema: public; Owner: ceserlodai_user
--

CREATE SEQUENCE public."Categoria_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Categoria_id_seq" OWNER TO ceserlodai_user;

--
-- Name: Categoria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ceserlodai_user
--

ALTER SEQUENCE public."Categoria_id_seq" OWNED BY public."Categoria".id;


--
-- Name: Clasificacion; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public."Clasificacion" (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text NOT NULL
);


ALTER TABLE public."Clasificacion" OWNER TO ceserlodai_user;

--
-- Name: Clasificacion_id_seq; Type: SEQUENCE; Schema: public; Owner: ceserlodai_user
--

CREATE SEQUENCE public."Clasificacion_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Clasificacion_id_seq" OWNER TO ceserlodai_user;

--
-- Name: Clasificacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ceserlodai_user
--

ALTER SEQUENCE public."Clasificacion_id_seq" OWNED BY public."Clasificacion".id;


--
-- Name: Despacho; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public."Despacho" (
    id integer NOT NULL,
    fecha_despacho timestamp(3) without time zone NOT NULL,
    motivo text,
    cedula_destinatario text NOT NULL
);


ALTER TABLE public."Despacho" OWNER TO ceserlodai_user;

--
-- Name: Despacho_id_seq; Type: SEQUENCE; Schema: public; Owner: ceserlodai_user
--

CREATE SEQUENCE public."Despacho_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Despacho_id_seq" OWNER TO ceserlodai_user;

--
-- Name: Despacho_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ceserlodai_user
--

ALTER SEQUENCE public."Despacho_id_seq" OWNED BY public."Despacho".id;


--
-- Name: Despachos_Renglones; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public."Despachos_Renglones" (
    id integer NOT NULL,
    id_renglon integer NOT NULL,
    id_despacho integer NOT NULL
);


ALTER TABLE public."Despachos_Renglones" OWNER TO ceserlodai_user;

--
-- Name: Despachos_Renglones_id_seq; Type: SEQUENCE; Schema: public; Owner: ceserlodai_user
--

CREATE SEQUENCE public."Despachos_Renglones_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Despachos_Renglones_id_seq" OWNER TO ceserlodai_user;

--
-- Name: Despachos_Renglones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ceserlodai_user
--

ALTER SEQUENCE public."Despachos_Renglones_id_seq" OWNED BY public."Despachos_Renglones".id;


--
-- Name: Destinatario; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public."Destinatario" (
    cedula text NOT NULL,
    nombres text NOT NULL,
    apellidos text NOT NULL,
    estado_civil text NOT NULL,
    id_armamento text NOT NULL,
    situacion_profesional text NOT NULL,
    estado text NOT NULL,
    id_unidad text NOT NULL,
    id_categoria text NOT NULL,
    id_grado text NOT NULL,
    id_componente text NOT NULL
);


ALTER TABLE public."Destinatario" OWNER TO ceserlodai_user;

--
-- Name: Devolucion; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public."Devolucion" (
    id integer NOT NULL,
    id_serial text NOT NULL,
    fecha_devolucion timestamp(3) without time zone NOT NULL,
    motivo text NOT NULL
);


ALTER TABLE public."Devolucion" OWNER TO ceserlodai_user;

--
-- Name: Devolucion_id_seq; Type: SEQUENCE; Schema: public; Owner: ceserlodai_user
--

CREATE SEQUENCE public."Devolucion_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Devolucion_id_seq" OWNER TO ceserlodai_user;

--
-- Name: Devolucion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ceserlodai_user
--

ALTER SEQUENCE public."Devolucion_id_seq" OWNED BY public."Devolucion".id;


--
-- Name: PasswordResetToken; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public."PasswordResetToken" (
    id text NOT NULL,
    email text NOT NULL,
    token text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PasswordResetToken" OWNER TO ceserlodai_user;

--
-- Name: Permiso; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public."Permiso" (
    id integer NOT NULL,
    permiso text NOT NULL,
    descripcion text NOT NULL,
    key text NOT NULL
);


ALTER TABLE public."Permiso" OWNER TO ceserlodai_user;

--
-- Name: Permiso_id_seq; Type: SEQUENCE; Schema: public; Owner: ceserlodai_user
--

CREATE SEQUENCE public."Permiso_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Permiso_id_seq" OWNER TO ceserlodai_user;

--
-- Name: Permiso_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ceserlodai_user
--

ALTER SEQUENCE public."Permiso_id_seq" OWNED BY public."Permiso".id;


--
-- Name: Recepcion; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public."Recepcion" (
    id integer NOT NULL,
    fecha_recepcion timestamp(3) without time zone NOT NULL,
    motivo text
);


ALTER TABLE public."Recepcion" OWNER TO ceserlodai_user;

--
-- Name: Recepcion_id_seq; Type: SEQUENCE; Schema: public; Owner: ceserlodai_user
--

CREATE SEQUENCE public."Recepcion_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Recepcion_id_seq" OWNER TO ceserlodai_user;

--
-- Name: Recepcion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ceserlodai_user
--

ALTER SEQUENCE public."Recepcion_id_seq" OWNED BY public."Recepcion".id;


--
-- Name: Recepciones_Renglones; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public."Recepciones_Renglones" (
    id integer NOT NULL,
    id_recepcion integer NOT NULL,
    id_renglon integer NOT NULL,
    cantidad integer NOT NULL,
    fecha_fabricacion timestamp(3) without time zone,
    fecha_vencimiento timestamp(3) without time zone
);


ALTER TABLE public."Recepciones_Renglones" OWNER TO ceserlodai_user;

--
-- Name: Recepciones_Renglones_id_seq; Type: SEQUENCE; Schema: public; Owner: ceserlodai_user
--

CREATE SEQUENCE public."Recepciones_Renglones_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Recepciones_Renglones_id_seq" OWNER TO ceserlodai_user;

--
-- Name: Recepciones_Renglones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ceserlodai_user
--

ALTER SEQUENCE public."Recepciones_Renglones_id_seq" OWNED BY public."Recepciones_Renglones".id;


--
-- Name: Renglones; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public."Renglones" (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text NOT NULL,
    tipo text,
    stock_minimo integer DEFAULT 1 NOT NULL,
    stock_maximo integer,
    numero_parte text,
    peso numeric(65,30) DEFAULT 1 NOT NULL,
    estado public."RenglonStates" DEFAULT 'Activo'::public."RenglonStates",
    "unidadEmpaqueId" integer NOT NULL,
    "clasificacionId" integer NOT NULL,
    "categoriaId" integer NOT NULL
);


ALTER TABLE public."Renglones" OWNER TO ceserlodai_user;

--
-- Name: Renglones_id_seq; Type: SEQUENCE; Schema: public; Owner: ceserlodai_user
--

CREATE SEQUENCE public."Renglones_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Renglones_id_seq" OWNER TO ceserlodai_user;

--
-- Name: Renglones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ceserlodai_user
--

ALTER SEQUENCE public."Renglones_id_seq" OWNED BY public."Renglones".id;


--
-- Name: Rol; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public."Rol" (
    id integer NOT NULL,
    rol text NOT NULL,
    descripcion text NOT NULL
);


ALTER TABLE public."Rol" OWNER TO ceserlodai_user;

--
-- Name: Rol_id_seq; Type: SEQUENCE; Schema: public; Owner: ceserlodai_user
--

CREATE SEQUENCE public."Rol_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Rol_id_seq" OWNER TO ceserlodai_user;

--
-- Name: Rol_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ceserlodai_user
--

ALTER SEQUENCE public."Rol_id_seq" OWNED BY public."Rol".id;


--
-- Name: Roles_Permisos; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public."Roles_Permisos" (
    id integer NOT NULL,
    rol_nombre text NOT NULL,
    permiso_key text NOT NULL,
    active boolean
);


ALTER TABLE public."Roles_Permisos" OWNER TO ceserlodai_user;

--
-- Name: Roles_Permisos_id_seq; Type: SEQUENCE; Schema: public; Owner: ceserlodai_user
--

CREATE SEQUENCE public."Roles_Permisos_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Roles_Permisos_id_seq" OWNER TO ceserlodai_user;

--
-- Name: Roles_Permisos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ceserlodai_user
--

ALTER SEQUENCE public."Roles_Permisos_id_seq" OWNED BY public."Roles_Permisos".id;


--
-- Name: Serial; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public."Serial" (
    id_recepcion integer NOT NULL,
    serial text NOT NULL,
    estado text
);


ALTER TABLE public."Serial" OWNER TO ceserlodai_user;

--
-- Name: Session; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "sessionToken" text NOT NULL,
    "userId" text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Session" OWNER TO ceserlodai_user;

--
-- Name: Sistemas; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public."Sistemas" (
    id text NOT NULL,
    nombre text NOT NULL,
    descripcion text NOT NULL,
    existencia integer NOT NULL,
    estado text NOT NULL,
    id_almacen integer NOT NULL
);


ALTER TABLE public."Sistemas" OWNER TO ceserlodai_user;

--
-- Name: Subsistemas; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public."Subsistemas" (
    id text NOT NULL,
    nombre text NOT NULL,
    descripcion text NOT NULL,
    existencia integer NOT NULL,
    estado text NOT NULL,
    sistema text NOT NULL,
    id_almacen integer NOT NULL
);


ALTER TABLE public."Subsistemas" OWNER TO ceserlodai_user;

--
-- Name: UnidadEmpaque; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public."UnidadEmpaque" (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text NOT NULL,
    tipo_medida public."Medidas" NOT NULL,
    peso numeric(65,30),
    abreviacion text
);


ALTER TABLE public."UnidadEmpaque" OWNER TO ceserlodai_user;

--
-- Name: UnidadEmpaque_id_seq; Type: SEQUENCE; Schema: public; Owner: ceserlodai_user
--

CREATE SEQUENCE public."UnidadEmpaque_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."UnidadEmpaque_id_seq" OWNER TO ceserlodai_user;

--
-- Name: UnidadEmpaque_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ceserlodai_user
--

ALTER SEQUENCE public."UnidadEmpaque_id_seq" OWNED BY public."UnidadEmpaque".id;


--
-- Name: User; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public."User" (
    id text NOT NULL,
    name text,
    email text,
    password text,
    "facialID" text,
    "emailVerified" timestamp(3) without time zone,
    image text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    rol_nombre text DEFAULT 'Basico'::text NOT NULL
);


ALTER TABLE public."User" OWNER TO ceserlodai_user;

--
-- Name: VerificationToken; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public."VerificationToken" (
    identifier text NOT NULL,
    token text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."VerificationToken" OWNER TO ceserlodai_user;

--
-- Name: almacenes; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public.almacenes (
    id integer NOT NULL,
    nombre text NOT NULL,
    ubicacion text NOT NULL
);


ALTER TABLE public.almacenes OWNER TO ceserlodai_user;

--
-- Name: categorias_militares; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public.categorias_militares (
    id text NOT NULL,
    nombre text NOT NULL,
    abreviatura text NOT NULL,
    estado text NOT NULL
);


ALTER TABLE public.categorias_militares OWNER TO ceserlodai_user;

--
-- Name: componentes_militares; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public.componentes_militares (
    id text NOT NULL,
    nombre text NOT NULL,
    descripcion text NOT NULL,
    estado text NOT NULL,
    ultima_edicion timestamp(3) without time zone NOT NULL,
    fecha_eliminado timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.componentes_militares OWNER TO ceserlodai_user;

--
-- Name: despachos; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public.despachos (
    id text NOT NULL,
    motivo text NOT NULL,
    cedula_destinatario text NOT NULL
);


ALTER TABLE public.despachos OWNER TO ceserlodai_user;

--
-- Name: despachos_detalles; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public.despachos_detalles (
    id text NOT NULL,
    cantidad integer NOT NULL,
    id_despacho text NOT NULL,
    id_renglon text NOT NULL,
    id_subsistema text NOT NULL,
    id_sistema text NOT NULL,
    "sistemasId" text,
    "subsistemasId" text
);


ALTER TABLE public.despachos_detalles OWNER TO ceserlodai_user;

--
-- Name: destinatarios_militares; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public.destinatarios_militares (
    cedula text NOT NULL,
    nombres text NOT NULL,
    apellidos text NOT NULL,
    telefono text NOT NULL,
    correo text NOT NULL,
    cargo text NOT NULL,
    direccion_domicilio text NOT NULL,
    id_grado text NOT NULL,
    id_categoria text NOT NULL,
    id_componente text NOT NULL,
    id_unidad text NOT NULL
);


ALTER TABLE public.destinatarios_militares OWNER TO ceserlodai_user;

--
-- Name: grados_militares; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public.grados_militares (
    id text NOT NULL,
    nombre text NOT NULL,
    abreviatura text NOT NULL,
    orden integer NOT NULL,
    estado text NOT NULL,
    ultima_edicion timestamp(3) without time zone NOT NULL,
    fecha_eliminado timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.grados_militares OWNER TO ceserlodai_user;

--
-- Name: personal_militar; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public.personal_militar (
    cedula text NOT NULL,
    nombres text NOT NULL,
    apellidos text NOT NULL,
    estado_civil text NOT NULL,
    id_armamento text NOT NULL,
    situacion_profesional text NOT NULL,
    estado text NOT NULL,
    id_unidad text NOT NULL,
    id_categoria text NOT NULL,
    id_grado text NOT NULL,
    id_componente text NOT NULL
);


ALTER TABLE public.personal_militar OWNER TO ceserlodai_user;

--
-- Name: redis; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public.redis (
    id text NOT NULL,
    nombre text NOT NULL,
    descripcion text NOT NULL,
    ubicacion text NOT NULL
);


ALTER TABLE public.redis OWNER TO ceserlodai_user;

--
-- Name: reposos; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public.reposos (
    id text NOT NULL
);


ALTER TABLE public.reposos OWNER TO ceserlodai_user;

--
-- Name: unidades_militares; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public.unidades_militares (
    id text NOT NULL,
    nombre text NOT NULL,
    descripcion text NOT NULL,
    ubicacion text NOT NULL,
    id_zodi text NOT NULL
);


ALTER TABLE public.unidades_militares OWNER TO ceserlodai_user;

--
-- Name: zodis; Type: TABLE; Schema: public; Owner: ceserlodai_user
--

CREATE TABLE public.zodis (
    id text NOT NULL,
    nombre text NOT NULL,
    descripcion text NOT NULL,
    ubicacion text NOT NULL,
    id_redi text NOT NULL
);


ALTER TABLE public.zodis OWNER TO ceserlodai_user;

--
-- Name: Categoria id; Type: DEFAULT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Categoria" ALTER COLUMN id SET DEFAULT nextval('public."Categoria_id_seq"'::regclass);


--
-- Name: Clasificacion id; Type: DEFAULT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Clasificacion" ALTER COLUMN id SET DEFAULT nextval('public."Clasificacion_id_seq"'::regclass);


--
-- Name: Despacho id; Type: DEFAULT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Despacho" ALTER COLUMN id SET DEFAULT nextval('public."Despacho_id_seq"'::regclass);


--
-- Name: Despachos_Renglones id; Type: DEFAULT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Despachos_Renglones" ALTER COLUMN id SET DEFAULT nextval('public."Despachos_Renglones_id_seq"'::regclass);


--
-- Name: Devolucion id; Type: DEFAULT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Devolucion" ALTER COLUMN id SET DEFAULT nextval('public."Devolucion_id_seq"'::regclass);


--
-- Name: Permiso id; Type: DEFAULT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Permiso" ALTER COLUMN id SET DEFAULT nextval('public."Permiso_id_seq"'::regclass);


--
-- Name: Recepcion id; Type: DEFAULT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Recepcion" ALTER COLUMN id SET DEFAULT nextval('public."Recepcion_id_seq"'::regclass);


--
-- Name: Recepciones_Renglones id; Type: DEFAULT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Recepciones_Renglones" ALTER COLUMN id SET DEFAULT nextval('public."Recepciones_Renglones_id_seq"'::regclass);


--
-- Name: Renglones id; Type: DEFAULT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Renglones" ALTER COLUMN id SET DEFAULT nextval('public."Renglones_id_seq"'::regclass);


--
-- Name: Rol id; Type: DEFAULT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Rol" ALTER COLUMN id SET DEFAULT nextval('public."Rol_id_seq"'::regclass);


--
-- Name: Roles_Permisos id; Type: DEFAULT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Roles_Permisos" ALTER COLUMN id SET DEFAULT nextval('public."Roles_Permisos_id_seq"'::regclass);


--
-- Name: UnidadEmpaque id; Type: DEFAULT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."UnidadEmpaque" ALTER COLUMN id SET DEFAULT nextval('public."UnidadEmpaque_id_seq"'::regclass);


--
-- Data for Name: Account; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public."Account" (id, "userId", type, provider, "providerAccountId", refresh_token, access_token, expires_at, token_type, scope, id_token, session_state) FROM stdin;
\.
COPY public."Account" (id, "userId", type, provider, "providerAccountId", refresh_token, access_token, expires_at, token_type, scope, id_token, session_state) FROM '$$PATH$$/3409.dat';

--
-- Data for Name: Categoria; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public."Categoria" (id, nombre, descripcion) FROM stdin;
\.
COPY public."Categoria" (id, nombre, descripcion) FROM '$$PATH$$/3425.dat';

--
-- Data for Name: Clasificacion; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public."Clasificacion" (id, nombre, descripcion) FROM stdin;
\.
COPY public."Clasificacion" (id, nombre, descripcion) FROM '$$PATH$$/3427.dat';

--
-- Data for Name: Despacho; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public."Despacho" (id, fecha_despacho, motivo, cedula_destinatario) FROM stdin;
\.
COPY public."Despacho" (id, fecha_despacho, motivo, cedula_destinatario) FROM '$$PATH$$/3442.dat';

--
-- Data for Name: Despachos_Renglones; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public."Despachos_Renglones" (id, id_renglon, id_despacho) FROM stdin;
\.
COPY public."Despachos_Renglones" (id, id_renglon, id_despacho) FROM '$$PATH$$/3444.dat';

--
-- Data for Name: Destinatario; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public."Destinatario" (cedula, nombres, apellidos, estado_civil, id_armamento, situacion_profesional, estado, id_unidad, id_categoria, id_grado, id_componente) FROM stdin;
\.
COPY public."Destinatario" (cedula, nombres, apellidos, estado_civil, id_armamento, situacion_profesional, estado, id_unidad, id_categoria, id_grado, id_componente) FROM '$$PATH$$/3445.dat';

--
-- Data for Name: Devolucion; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public."Devolucion" (id, id_serial, fecha_devolucion, motivo) FROM stdin;
\.
COPY public."Devolucion" (id, id_serial, fecha_devolucion, motivo) FROM '$$PATH$$/3440.dat';

--
-- Data for Name: PasswordResetToken; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public."PasswordResetToken" (id, email, token, expires) FROM stdin;
\.
COPY public."PasswordResetToken" (id, email, token, expires) FROM '$$PATH$$/3413.dat';

--
-- Data for Name: Permiso; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public."Permiso" (id, permiso, descripcion, key) FROM stdin;
\.
COPY public."Permiso" (id, permiso, descripcion, key) FROM '$$PATH$$/3419.dat';

--
-- Data for Name: Recepcion; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public."Recepcion" (id, fecha_recepcion, motivo) FROM stdin;
\.
COPY public."Recepcion" (id, fecha_recepcion, motivo) FROM '$$PATH$$/3435.dat';

--
-- Data for Name: Recepciones_Renglones; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public."Recepciones_Renglones" (id, id_recepcion, id_renglon, cantidad, fecha_fabricacion, fecha_vencimiento) FROM stdin;
\.
COPY public."Recepciones_Renglones" (id, id_recepcion, id_renglon, cantidad, fecha_fabricacion, fecha_vencimiento) FROM '$$PATH$$/3437.dat';

--
-- Data for Name: Renglones; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public."Renglones" (id, nombre, descripcion, tipo, stock_minimo, stock_maximo, numero_parte, peso, estado, "unidadEmpaqueId", "clasificacionId", "categoriaId") FROM stdin;
\.
COPY public."Renglones" (id, nombre, descripcion, tipo, stock_minimo, stock_maximo, numero_parte, peso, estado, "unidadEmpaqueId", "clasificacionId", "categoriaId") FROM '$$PATH$$/3421.dat';

--
-- Data for Name: Rol; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public."Rol" (id, rol, descripcion) FROM stdin;
\.
COPY public."Rol" (id, rol, descripcion) FROM '$$PATH$$/3415.dat';

--
-- Data for Name: Roles_Permisos; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public."Roles_Permisos" (id, rol_nombre, permiso_key, active) FROM stdin;
\.
COPY public."Roles_Permisos" (id, rol_nombre, permiso_key, active) FROM '$$PATH$$/3417.dat';

--
-- Data for Name: Serial; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public."Serial" (id_recepcion, serial, estado) FROM stdin;
\.
COPY public."Serial" (id_recepcion, serial, estado) FROM '$$PATH$$/3438.dat';

--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public."Session" (id, "sessionToken", "userId", expires) FROM stdin;
\.
COPY public."Session" (id, "sessionToken", "userId", expires) FROM '$$PATH$$/3410.dat';

--
-- Data for Name: Sistemas; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public."Sistemas" (id, nombre, descripcion, existencia, estado, id_almacen) FROM stdin;
\.
COPY public."Sistemas" (id, nombre, descripcion, existencia, estado, id_almacen) FROM '$$PATH$$/3428.dat';

--
-- Data for Name: Subsistemas; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public."Subsistemas" (id, nombre, descripcion, existencia, estado, sistema, id_almacen) FROM stdin;
\.
COPY public."Subsistemas" (id, nombre, descripcion, existencia, estado, sistema, id_almacen) FROM '$$PATH$$/3429.dat';

--
-- Data for Name: UnidadEmpaque; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public."UnidadEmpaque" (id, nombre, descripcion, tipo_medida, peso, abreviacion) FROM stdin;
\.
COPY public."UnidadEmpaque" (id, nombre, descripcion, tipo_medida, peso, abreviacion) FROM '$$PATH$$/3423.dat';

--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public."User" (id, name, email, password, "facialID", "emailVerified", image, "createdAt", "updatedAt", rol_nombre) FROM stdin;
\.
COPY public."User" (id, name, email, password, "facialID", "emailVerified", image, "createdAt", "updatedAt", rol_nombre) FROM '$$PATH$$/3411.dat';

--
-- Data for Name: VerificationToken; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public."VerificationToken" (identifier, token, expires) FROM stdin;
\.
COPY public."VerificationToken" (identifier, token, expires) FROM '$$PATH$$/3412.dat';

--
-- Data for Name: almacenes; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public.almacenes (id, nombre, ubicacion) FROM stdin;
\.
COPY public.almacenes (id, nombre, ubicacion) FROM '$$PATH$$/3430.dat';

--
-- Data for Name: categorias_militares; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public.categorias_militares (id, nombre, abreviatura, estado) FROM stdin;
\.
COPY public.categorias_militares (id, nombre, abreviatura, estado) FROM '$$PATH$$/3448.dat';

--
-- Data for Name: componentes_militares; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public.componentes_militares (id, nombre, descripcion, estado, ultima_edicion, fecha_eliminado) FROM stdin;
\.
COPY public.componentes_militares (id, nombre, descripcion, estado, ultima_edicion, fecha_eliminado) FROM '$$PATH$$/3446.dat';

--
-- Data for Name: despachos; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public.despachos (id, motivo, cedula_destinatario) FROM stdin;
\.
COPY public.despachos (id, motivo, cedula_destinatario) FROM '$$PATH$$/3431.dat';

--
-- Data for Name: despachos_detalles; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public.despachos_detalles (id, cantidad, id_despacho, id_renglon, id_subsistema, id_sistema, "sistemasId", "subsistemasId") FROM stdin;
\.
COPY public.despachos_detalles (id, cantidad, id_despacho, id_renglon, id_subsistema, id_sistema, "sistemasId", "subsistemasId") FROM '$$PATH$$/3432.dat';

--
-- Data for Name: destinatarios_militares; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public.destinatarios_militares (cedula, nombres, apellidos, telefono, correo, cargo, direccion_domicilio, id_grado, id_categoria, id_componente, id_unidad) FROM stdin;
\.
COPY public.destinatarios_militares (cedula, nombres, apellidos, telefono, correo, cargo, direccion_domicilio, id_grado, id_categoria, id_componente, id_unidad) FROM '$$PATH$$/3433.dat';

--
-- Data for Name: grados_militares; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public.grados_militares (id, nombre, abreviatura, orden, estado, ultima_edicion, fecha_eliminado) FROM stdin;
\.
COPY public.grados_militares (id, nombre, abreviatura, orden, estado, ultima_edicion, fecha_eliminado) FROM '$$PATH$$/3447.dat';

--
-- Data for Name: personal_militar; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public.personal_militar (cedula, nombres, apellidos, estado_civil, id_armamento, situacion_profesional, estado, id_unidad, id_categoria, id_grado, id_componente) FROM stdin;
\.
COPY public.personal_militar (cedula, nombres, apellidos, estado_civil, id_armamento, situacion_profesional, estado, id_unidad, id_categoria, id_grado, id_componente) FROM '$$PATH$$/3452.dat';

--
-- Data for Name: redis; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public.redis (id, nombre, descripcion, ubicacion) FROM stdin;
\.
COPY public.redis (id, nombre, descripcion, ubicacion) FROM '$$PATH$$/3451.dat';

--
-- Data for Name: reposos; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public.reposos (id) FROM stdin;
\.
COPY public.reposos (id) FROM '$$PATH$$/3453.dat';

--
-- Data for Name: unidades_militares; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public.unidades_militares (id, nombre, descripcion, ubicacion, id_zodi) FROM stdin;
\.
COPY public.unidades_militares (id, nombre, descripcion, ubicacion, id_zodi) FROM '$$PATH$$/3449.dat';

--
-- Data for Name: zodis; Type: TABLE DATA; Schema: public; Owner: ceserlodai_user
--

COPY public.zodis (id, nombre, descripcion, ubicacion, id_redi) FROM stdin;
\.
COPY public.zodis (id, nombre, descripcion, ubicacion, id_redi) FROM '$$PATH$$/3450.dat';

--
-- Name: Categoria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ceserlodai_user
--

SELECT pg_catalog.setval('public."Categoria_id_seq"', 1, true);


--
-- Name: Clasificacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ceserlodai_user
--

SELECT pg_catalog.setval('public."Clasificacion_id_seq"', 1, true);


--
-- Name: Despacho_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ceserlodai_user
--

SELECT pg_catalog.setval('public."Despacho_id_seq"', 1, false);


--
-- Name: Despachos_Renglones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ceserlodai_user
--

SELECT pg_catalog.setval('public."Despachos_Renglones_id_seq"', 1, false);


--
-- Name: Devolucion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ceserlodai_user
--

SELECT pg_catalog.setval('public."Devolucion_id_seq"', 1, false);


--
-- Name: Permiso_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ceserlodai_user
--

SELECT pg_catalog.setval('public."Permiso_id_seq"', 1, false);


--
-- Name: Recepcion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ceserlodai_user
--

SELECT pg_catalog.setval('public."Recepcion_id_seq"', 4, true);


--
-- Name: Recepciones_Renglones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ceserlodai_user
--

SELECT pg_catalog.setval('public."Recepciones_Renglones_id_seq"', 5, true);


--
-- Name: Renglones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ceserlodai_user
--

SELECT pg_catalog.setval('public."Renglones_id_seq"', 9, true);


--
-- Name: Rol_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ceserlodai_user
--

SELECT pg_catalog.setval('public."Rol_id_seq"', 1, false);


--
-- Name: Roles_Permisos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ceserlodai_user
--

SELECT pg_catalog.setval('public."Roles_Permisos_id_seq"', 1, false);


--
-- Name: UnidadEmpaque_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ceserlodai_user
--

SELECT pg_catalog.setval('public."UnidadEmpaque_id_seq"', 1, true);


--
-- Name: Account Account_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_pkey" PRIMARY KEY (id);


--
-- Name: Categoria Categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Categoria"
    ADD CONSTRAINT "Categoria_pkey" PRIMARY KEY (id);


--
-- Name: Clasificacion Clasificacion_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Clasificacion"
    ADD CONSTRAINT "Clasificacion_pkey" PRIMARY KEY (id);


--
-- Name: Despacho Despacho_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Despacho"
    ADD CONSTRAINT "Despacho_pkey" PRIMARY KEY (id);


--
-- Name: Despachos_Renglones Despachos_Renglones_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Despachos_Renglones"
    ADD CONSTRAINT "Despachos_Renglones_pkey" PRIMARY KEY (id);


--
-- Name: Destinatario Destinatario_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Destinatario"
    ADD CONSTRAINT "Destinatario_pkey" PRIMARY KEY (cedula);


--
-- Name: Devolucion Devolucion_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Devolucion"
    ADD CONSTRAINT "Devolucion_pkey" PRIMARY KEY (id);


--
-- Name: PasswordResetToken PasswordResetToken_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_pkey" PRIMARY KEY (id);


--
-- Name: Permiso Permiso_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Permiso"
    ADD CONSTRAINT "Permiso_pkey" PRIMARY KEY (id);


--
-- Name: Recepcion Recepcion_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Recepcion"
    ADD CONSTRAINT "Recepcion_pkey" PRIMARY KEY (id);


--
-- Name: Recepciones_Renglones Recepciones_Renglones_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Recepciones_Renglones"
    ADD CONSTRAINT "Recepciones_Renglones_pkey" PRIMARY KEY (id);


--
-- Name: Renglones Renglones_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Renglones"
    ADD CONSTRAINT "Renglones_pkey" PRIMARY KEY (id);


--
-- Name: Rol Rol_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Rol"
    ADD CONSTRAINT "Rol_pkey" PRIMARY KEY (id);


--
-- Name: Roles_Permisos Roles_Permisos_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Roles_Permisos"
    ADD CONSTRAINT "Roles_Permisos_pkey" PRIMARY KEY (id);


--
-- Name: Serial Serial_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Serial"
    ADD CONSTRAINT "Serial_pkey" PRIMARY KEY (serial);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: Sistemas Sistemas_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Sistemas"
    ADD CONSTRAINT "Sistemas_pkey" PRIMARY KEY (id);


--
-- Name: Subsistemas Subsistemas_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Subsistemas"
    ADD CONSTRAINT "Subsistemas_pkey" PRIMARY KEY (id);


--
-- Name: UnidadEmpaque UnidadEmpaque_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."UnidadEmpaque"
    ADD CONSTRAINT "UnidadEmpaque_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: almacenes almacenes_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.almacenes
    ADD CONSTRAINT almacenes_pkey PRIMARY KEY (id);


--
-- Name: categorias_militares categorias_militares_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.categorias_militares
    ADD CONSTRAINT categorias_militares_pkey PRIMARY KEY (id);


--
-- Name: componentes_militares componentes_militares_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.componentes_militares
    ADD CONSTRAINT componentes_militares_pkey PRIMARY KEY (id);


--
-- Name: despachos_detalles despachos_detalles_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.despachos_detalles
    ADD CONSTRAINT despachos_detalles_pkey PRIMARY KEY (id);


--
-- Name: despachos despachos_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.despachos
    ADD CONSTRAINT despachos_pkey PRIMARY KEY (id);


--
-- Name: destinatarios_militares destinatarios_militares_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.destinatarios_militares
    ADD CONSTRAINT destinatarios_militares_pkey PRIMARY KEY (cedula);


--
-- Name: grados_militares grados_militares_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.grados_militares
    ADD CONSTRAINT grados_militares_pkey PRIMARY KEY (id);


--
-- Name: personal_militar personal_militar_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.personal_militar
    ADD CONSTRAINT personal_militar_pkey PRIMARY KEY (cedula);


--
-- Name: redis redis_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.redis
    ADD CONSTRAINT redis_pkey PRIMARY KEY (id);


--
-- Name: reposos reposos_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.reposos
    ADD CONSTRAINT reposos_pkey PRIMARY KEY (id);


--
-- Name: unidades_militares unidades_militares_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.unidades_militares
    ADD CONSTRAINT unidades_militares_pkey PRIMARY KEY (id);


--
-- Name: zodis zodis_pkey; Type: CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.zodis
    ADD CONSTRAINT zodis_pkey PRIMARY KEY (id);


--
-- Name: Account_provider_providerAccountId_key; Type: INDEX; Schema: public; Owner: ceserlodai_user
--

CREATE UNIQUE INDEX "Account_provider_providerAccountId_key" ON public."Account" USING btree (provider, "providerAccountId");


--
-- Name: Categoria_nombre_key; Type: INDEX; Schema: public; Owner: ceserlodai_user
--

CREATE UNIQUE INDEX "Categoria_nombre_key" ON public."Categoria" USING btree (nombre);


--
-- Name: Clasificacion_nombre_key; Type: INDEX; Schema: public; Owner: ceserlodai_user
--

CREATE UNIQUE INDEX "Clasificacion_nombre_key" ON public."Clasificacion" USING btree (nombre);


--
-- Name: PasswordResetToken_email_token_key; Type: INDEX; Schema: public; Owner: ceserlodai_user
--

CREATE UNIQUE INDEX "PasswordResetToken_email_token_key" ON public."PasswordResetToken" USING btree (email, token);


--
-- Name: PasswordResetToken_token_key; Type: INDEX; Schema: public; Owner: ceserlodai_user
--

CREATE UNIQUE INDEX "PasswordResetToken_token_key" ON public."PasswordResetToken" USING btree (token);


--
-- Name: Permiso_key_key; Type: INDEX; Schema: public; Owner: ceserlodai_user
--

CREATE UNIQUE INDEX "Permiso_key_key" ON public."Permiso" USING btree (key);


--
-- Name: Renglones_nombre_key; Type: INDEX; Schema: public; Owner: ceserlodai_user
--

CREATE UNIQUE INDEX "Renglones_nombre_key" ON public."Renglones" USING btree (nombre);


--
-- Name: Rol_rol_key; Type: INDEX; Schema: public; Owner: ceserlodai_user
--

CREATE UNIQUE INDEX "Rol_rol_key" ON public."Rol" USING btree (rol);


--
-- Name: Session_sessionToken_key; Type: INDEX; Schema: public; Owner: ceserlodai_user
--

CREATE UNIQUE INDEX "Session_sessionToken_key" ON public."Session" USING btree ("sessionToken");


--
-- Name: UnidadEmpaque_nombre_key; Type: INDEX; Schema: public; Owner: ceserlodai_user
--

CREATE UNIQUE INDEX "UnidadEmpaque_nombre_key" ON public."UnidadEmpaque" USING btree (nombre);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: ceserlodai_user
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_facialID_key; Type: INDEX; Schema: public; Owner: ceserlodai_user
--

CREATE UNIQUE INDEX "User_facialID_key" ON public."User" USING btree ("facialID");


--
-- Name: VerificationToken_identifier_token_key; Type: INDEX; Schema: public; Owner: ceserlodai_user
--

CREATE UNIQUE INDEX "VerificationToken_identifier_token_key" ON public."VerificationToken" USING btree (identifier, token);


--
-- Name: VerificationToken_token_key; Type: INDEX; Schema: public; Owner: ceserlodai_user
--

CREATE UNIQUE INDEX "VerificationToken_token_key" ON public."VerificationToken" USING btree (token);


--
-- Name: Account Account_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Despacho Despacho_cedula_destinatario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Despacho"
    ADD CONSTRAINT "Despacho_cedula_destinatario_fkey" FOREIGN KEY (cedula_destinatario) REFERENCES public."Destinatario"(cedula) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Despachos_Renglones Despachos_Renglones_id_despacho_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Despachos_Renglones"
    ADD CONSTRAINT "Despachos_Renglones_id_despacho_fkey" FOREIGN KEY (id_despacho) REFERENCES public."Despacho"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Despachos_Renglones Despachos_Renglones_id_renglon_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Despachos_Renglones"
    ADD CONSTRAINT "Despachos_Renglones_id_renglon_fkey" FOREIGN KEY (id_renglon) REFERENCES public."Renglones"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Destinatario Destinatario_id_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Destinatario"
    ADD CONSTRAINT "Destinatario_id_categoria_fkey" FOREIGN KEY (id_categoria) REFERENCES public.categorias_militares(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Destinatario Destinatario_id_componente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Destinatario"
    ADD CONSTRAINT "Destinatario_id_componente_fkey" FOREIGN KEY (id_componente) REFERENCES public.componentes_militares(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Destinatario Destinatario_id_grado_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Destinatario"
    ADD CONSTRAINT "Destinatario_id_grado_fkey" FOREIGN KEY (id_grado) REFERENCES public.grados_militares(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Destinatario Destinatario_id_unidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Destinatario"
    ADD CONSTRAINT "Destinatario_id_unidad_fkey" FOREIGN KEY (id_unidad) REFERENCES public.unidades_militares(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Devolucion Devolucion_id_serial_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Devolucion"
    ADD CONSTRAINT "Devolucion_id_serial_fkey" FOREIGN KEY (id_serial) REFERENCES public."Serial"(serial) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Recepciones_Renglones Recepciones_Renglones_id_recepcion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Recepciones_Renglones"
    ADD CONSTRAINT "Recepciones_Renglones_id_recepcion_fkey" FOREIGN KEY (id_recepcion) REFERENCES public."Recepcion"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Recepciones_Renglones Recepciones_Renglones_id_renglon_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Recepciones_Renglones"
    ADD CONSTRAINT "Recepciones_Renglones_id_renglon_fkey" FOREIGN KEY (id_renglon) REFERENCES public."Renglones"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Renglones Renglones_categoriaId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Renglones"
    ADD CONSTRAINT "Renglones_categoriaId_fkey" FOREIGN KEY ("categoriaId") REFERENCES public."Categoria"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Renglones Renglones_clasificacionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Renglones"
    ADD CONSTRAINT "Renglones_clasificacionId_fkey" FOREIGN KEY ("clasificacionId") REFERENCES public."Clasificacion"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Renglones Renglones_unidadEmpaqueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Renglones"
    ADD CONSTRAINT "Renglones_unidadEmpaqueId_fkey" FOREIGN KEY ("unidadEmpaqueId") REFERENCES public."UnidadEmpaque"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Roles_Permisos Roles_Permisos_permiso_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Roles_Permisos"
    ADD CONSTRAINT "Roles_Permisos_permiso_key_fkey" FOREIGN KEY (permiso_key) REFERENCES public."Permiso"(key) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Roles_Permisos Roles_Permisos_rol_nombre_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Roles_Permisos"
    ADD CONSTRAINT "Roles_Permisos_rol_nombre_fkey" FOREIGN KEY (rol_nombre) REFERENCES public."Rol"(rol) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Serial Serial_id_recepcion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Serial"
    ADD CONSTRAINT "Serial_id_recepcion_fkey" FOREIGN KEY (id_recepcion) REFERENCES public."Recepciones_Renglones"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Sistemas Sistemas_id_almacen_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Sistemas"
    ADD CONSTRAINT "Sistemas_id_almacen_fkey" FOREIGN KEY (id_almacen) REFERENCES public.almacenes(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Subsistemas Subsistemas_id_almacen_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."Subsistemas"
    ADD CONSTRAINT "Subsistemas_id_almacen_fkey" FOREIGN KEY (id_almacen) REFERENCES public.almacenes(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: User User_rol_nombre_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_rol_nombre_fkey" FOREIGN KEY (rol_nombre) REFERENCES public."Rol"(rol) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: despachos despachos_cedula_destinatario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.despachos
    ADD CONSTRAINT despachos_cedula_destinatario_fkey FOREIGN KEY (cedula_destinatario) REFERENCES public.destinatarios_militares(cedula) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: despachos_detalles despachos_detalles_id_despacho_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.despachos_detalles
    ADD CONSTRAINT despachos_detalles_id_despacho_fkey FOREIGN KEY (id_despacho) REFERENCES public.despachos(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: despachos_detalles despachos_detalles_sistemasId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.despachos_detalles
    ADD CONSTRAINT "despachos_detalles_sistemasId_fkey" FOREIGN KEY ("sistemasId") REFERENCES public."Sistemas"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: despachos_detalles despachos_detalles_subsistemasId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.despachos_detalles
    ADD CONSTRAINT "despachos_detalles_subsistemasId_fkey" FOREIGN KEY ("subsistemasId") REFERENCES public."Subsistemas"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: destinatarios_militares destinatarios_militares_id_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.destinatarios_militares
    ADD CONSTRAINT destinatarios_militares_id_categoria_fkey FOREIGN KEY (id_categoria) REFERENCES public.categorias_militares(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: destinatarios_militares destinatarios_militares_id_componente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.destinatarios_militares
    ADD CONSTRAINT destinatarios_militares_id_componente_fkey FOREIGN KEY (id_componente) REFERENCES public.componentes_militares(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: destinatarios_militares destinatarios_militares_id_grado_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.destinatarios_militares
    ADD CONSTRAINT destinatarios_militares_id_grado_fkey FOREIGN KEY (id_grado) REFERENCES public.grados_militares(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: destinatarios_militares destinatarios_militares_id_unidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.destinatarios_militares
    ADD CONSTRAINT destinatarios_militares_id_unidad_fkey FOREIGN KEY (id_unidad) REFERENCES public.unidades_militares(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: personal_militar personal_militar_id_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.personal_militar
    ADD CONSTRAINT personal_militar_id_categoria_fkey FOREIGN KEY (id_categoria) REFERENCES public.categorias_militares(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: personal_militar personal_militar_id_componente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.personal_militar
    ADD CONSTRAINT personal_militar_id_componente_fkey FOREIGN KEY (id_componente) REFERENCES public.componentes_militares(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: personal_militar personal_militar_id_grado_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.personal_militar
    ADD CONSTRAINT personal_militar_id_grado_fkey FOREIGN KEY (id_grado) REFERENCES public.grados_militares(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: personal_militar personal_militar_id_unidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.personal_militar
    ADD CONSTRAINT personal_militar_id_unidad_fkey FOREIGN KEY (id_unidad) REFERENCES public.unidades_militares(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: unidades_militares unidades_militares_id_zodi_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.unidades_militares
    ADD CONSTRAINT unidades_militares_id_zodi_fkey FOREIGN KEY (id_zodi) REFERENCES public.zodis(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: zodis zodis_id_redi_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ceserlodai_user
--

ALTER TABLE ONLY public.zodis
    ADD CONSTRAINT zodis_id_redi_fkey FOREIGN KEY (id_redi) REFERENCES public.redis(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: ceserlodai_user
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON SEQUENCES TO ceserlodai_user;


--
-- Name: DEFAULT PRIVILEGES FOR TYPES; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON TYPES TO ceserlodai_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON FUNCTIONS TO ceserlodai_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON TABLES TO ceserlodai_user;


--
-- PostgreSQL database dump complete
--

