--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE ceserlodai;
--
-- Name: ceserlodai; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE ceserlodai WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Spanish_Spain.1252';


ALTER DATABASE ceserlodai OWNER TO postgres;

\connect ceserlodai

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: AdminPasswordStates; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AdminPasswordStates" AS ENUM (
    'Inhabilitada',
    'Activa'
);


ALTER TYPE public."AdminPasswordStates" OWNER TO postgres;

--
-- Name: Colores_Armamento; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Colores_Armamento" AS ENUM (
    'Amarillo',
    'Anaranjado',
    'Azul',
    'Blanco',
    'Camuflado',
    'Gris',
    'Marron',
    'Multicolor',
    'Negro',
    'Rojo',
    'Rosado',
    'Verde',
    'Cromado',
    'Pixelado',
    'Niquelado',
    'Plateado',
    'Olivo'
);


ALTER TYPE public."Colores_Armamento" OWNER TO postgres;

--
-- Name: Condiciones_Armamento; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Condiciones_Armamento" AS ENUM (
    'Operativo',
    'Inoperativo',
    'Inutilizado'
);


ALTER TYPE public."Condiciones_Armamento" OWNER TO postgres;

--
-- Name: Estados_Armamento; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Estados_Armamento" AS ENUM (
    'Asignado',
    'Robado',
    'Hurtado',
    'Extraviado',
    'Perdido',
    'Decomisado',
    'Cadena_Abastecimiento',
    'Reparacion'
);


ALTER TYPE public."Estados_Armamento" OWNER TO postgres;

--
-- Name: Estados_Pedidos; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Estados_Pedidos" AS ENUM (
    'Cancelado',
    'En_proceso',
    'Recibido',
    'Pendiente'
);


ALTER TYPE public."Estados_Pedidos" OWNER TO postgres;

--
-- Name: Generos; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Generos" AS ENUM (
    'Femenino',
    'Masculino'
);


ALTER TYPE public."Generos" OWNER TO postgres;

--
-- Name: Medidas; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Medidas" AS ENUM (
    'MILILITROS',
    'LITROS',
    'ONZAS',
    'LIBRAS',
    'TONELADAS',
    'KILOGRAMOS',
    'GRAMOS',
    'UNIDADES'
);


ALTER TYPE public."Medidas" OWNER TO postgres;

--
-- Name: RenglonStates; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."RenglonStates" AS ENUM (
    'Activo',
    'Eliminado',
    'En Borrador',
    'Deshabilitado'
);


ALTER TYPE public."RenglonStates" OWNER TO postgres;

--
-- Name: Servicios; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Servicios" AS ENUM (
    'Armamento',
    'Abastecimiento'
);


ALTER TYPE public."Servicios" OWNER TO postgres;

--
-- Name: Tipos_Cedulas; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Tipos_Cedulas" AS ENUM (
    'V',
    'E',
    'J',
    'G',
    'R',
    'P'
);


ALTER TYPE public."Tipos_Cedulas" OWNER TO postgres;

--
-- Name: Tipos_Destinatarios; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Tipos_Destinatarios" AS ENUM (
    'Civil',
    'Militar'
);


ALTER TYPE public."Tipos_Destinatarios" OWNER TO postgres;

--
-- Name: Tipos_Proveedores; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Tipos_Proveedores" AS ENUM (
    'Empresa',
    'Persona',
    'Unidad'
);


ALTER TYPE public."Tipos_Proveedores" OWNER TO postgres;

--
-- Name: Usuarios_Estados; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Usuarios_Estados" AS ENUM (
    'Activo',
    'Bloqueado'
);


ALTER TYPE public."Usuarios_Estados" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Accesorio_Arma; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Accesorio_Arma" (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text NOT NULL,
    id_modelo integer
);


ALTER TABLE public."Accesorio_Arma" OWNER TO postgres;

--
-- Name: Accesorio_Arma_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Accesorio_Arma_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Accesorio_Arma_id_seq" OWNER TO postgres;

--
-- Name: Accesorio_Arma_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Accesorio_Arma_id_seq" OWNED BY public."Accesorio_Arma".id;


--
-- Name: Account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Account" (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    provider text NOT NULL,
    "providerAccountId" text NOT NULL,
    refresh_token text,
    access_token text,
    expires_at integer,
    token_type text,
    scope text,
    id_token text,
    session_state text
);


ALTER TABLE public."Account" OWNER TO postgres;

--
-- Name: Admin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Admin" (
    id integer NOT NULL,
    password text NOT NULL,
    state public."AdminPasswordStates" NOT NULL,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Admin" OWNER TO postgres;

--
-- Name: Admin_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Admin_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Admin_id_seq" OWNER TO postgres;

--
-- Name: Admin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Admin_id_seq" OWNED BY public."Admin".id;


--
-- Name: Almacen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Almacen" (
    id integer NOT NULL,
    nombre text NOT NULL,
    ubicacion text NOT NULL,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL,
    id_unidad integer,
    servicio public."Servicios"
);


ALTER TABLE public."Almacen" OWNER TO postgres;

--
-- Name: Almacen_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Almacen_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Almacen_id_seq" OWNER TO postgres;

--
-- Name: Almacen_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Almacen_id_seq" OWNED BY public."Almacen".id;


--
-- Name: Armamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Armamento" (
    descripcion text,
    id integer NOT NULL,
    serial_armazon text NOT NULL,
    serial_canon text NOT NULL,
    fecha_fabricacion timestamp(3) without time zone,
    lugar_fabricacion text,
    numero_causa text,
    id_unidad integer NOT NULL,
    id_almacen integer NOT NULL,
    pasillo text,
    id_modelo integer NOT NULL,
    color public."Colores_Armamento" NOT NULL,
    condicion public."Condiciones_Armamento" NOT NULL,
    estado public."Estados_Armamento" NOT NULL
);


ALTER TABLE public."Armamento" OWNER TO postgres;

--
-- Name: Armamento_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Armamento_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Armamento_id_seq" OWNER TO postgres;

--
-- Name: Armamento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Armamento_id_seq" OWNED BY public."Armamento".id;


--
-- Name: Asistencia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Asistencia" (
    id integer NOT NULL,
    id_usuario text NOT NULL,
    fecha_realizado timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    hora_entrada timestamp(3) without time zone,
    hora_salida timestamp(3) without time zone
);


ALTER TABLE public."Asistencia" OWNER TO postgres;

--
-- Name: Asistencia_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Asistencia_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Asistencia_id_seq" OWNER TO postgres;

--
-- Name: Asistencia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Asistencia_id_seq" OWNED BY public."Asistencia".id;


--
-- Name: AttendanceCredentials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AttendanceCredentials" (
    id integer NOT NULL,
    show_credentials boolean DEFAULT true NOT NULL
);


ALTER TABLE public."AttendanceCredentials" OWNER TO postgres;

--
-- Name: AttendanceCredentials_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AttendanceCredentials_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AttendanceCredentials_id_seq" OWNER TO postgres;

--
-- Name: AttendanceCredentials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AttendanceCredentials_id_seq" OWNED BY public."AttendanceCredentials".id;


--
-- Name: Auditoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Auditoria" (
    id integer NOT NULL,
    id_usuario text NOT NULL,
    accion text NOT NULL,
    fecha_realizado timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Auditoria" OWNER TO postgres;

--
-- Name: Auditoria_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Auditoria_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Auditoria_id_seq" OWNER TO postgres;

--
-- Name: Auditoria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Auditoria_id_seq" OWNED BY public."Auditoria".id;


--
-- Name: Calibre; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Calibre" (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text
);


ALTER TABLE public."Calibre" OWNER TO postgres;

--
-- Name: Calibre_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Calibre_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Calibre_id_seq" OWNER TO postgres;

--
-- Name: Calibre_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Calibre_id_seq" OWNED BY public."Calibre".id;


--
-- Name: Categoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Categoria" (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text NOT NULL,
    id_clasificacion integer NOT NULL,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Categoria" OWNER TO postgres;

--
-- Name: Categoria_Militar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Categoria_Militar" (
    id integer NOT NULL,
    nombre text NOT NULL,
    abreviatura text NOT NULL,
    estado text,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Categoria_Militar" OWNER TO postgres;

--
-- Name: Categoria_Militar_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Categoria_Militar_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Categoria_Militar_id_seq" OWNER TO postgres;

--
-- Name: Categoria_Militar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Categoria_Militar_id_seq" OWNED BY public."Categoria_Militar".id;


--
-- Name: Categoria_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Categoria_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Categoria_id_seq" OWNER TO postgres;

--
-- Name: Categoria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Categoria_id_seq" OWNED BY public."Categoria".id;


--
-- Name: Categorias_Grados; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Categorias_Grados" (
    id integer NOT NULL,
    id_categoria integer NOT NULL,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL,
    id_grado integer NOT NULL
);


ALTER TABLE public."Categorias_Grados" OWNER TO postgres;

--
-- Name: Categorias_Grados_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Categorias_Grados_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Categorias_Grados_id_seq" OWNER TO postgres;

--
-- Name: Categorias_Grados_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Categorias_Grados_id_seq" OWNED BY public."Categorias_Grados".id;


--
-- Name: Clasificacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Clasificacion" (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text NOT NULL,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Clasificacion" OWNER TO postgres;

--
-- Name: Clasificacion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Clasificacion_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Clasificacion_id_seq" OWNER TO postgres;

--
-- Name: Clasificacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Clasificacion_id_seq" OWNED BY public."Clasificacion".id;


--
-- Name: Componente_Arma; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Componente_Arma" (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text NOT NULL,
    id_modelo integer NOT NULL
);


ALTER TABLE public."Componente_Arma" OWNER TO postgres;

--
-- Name: Componente_Arma_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Componente_Arma_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Componente_Arma_id_seq" OWNER TO postgres;

--
-- Name: Componente_Arma_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Componente_Arma_id_seq" OWNED BY public."Componente_Arma".id;


--
-- Name: Componente_Militar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Componente_Militar" (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text NOT NULL,
    estado text,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Componente_Militar" OWNER TO postgres;

--
-- Name: Componente_Militar_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Componente_Militar_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Componente_Militar_id_seq" OWNER TO postgres;

--
-- Name: Componente_Militar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Componente_Militar_id_seq" OWNED BY public."Componente_Militar".id;


--
-- Name: Despacho; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Despacho" (
    id integer NOT NULL,
    fecha_despacho timestamp(3) without time zone NOT NULL,
    motivo text,
    cedula_destinatario text NOT NULL,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL,
    cedula_abastecedor text NOT NULL,
    cedula_autorizador text NOT NULL,
    cedula_supervisor text,
    servicio public."Servicios"
);


ALTER TABLE public."Despacho" OWNER TO postgres;

--
-- Name: Despacho_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Despacho_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Despacho_id_seq" OWNER TO postgres;

--
-- Name: Despacho_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Despacho_id_seq" OWNED BY public."Despacho".id;


--
-- Name: Despachos_Renglones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Despachos_Renglones" (
    id integer NOT NULL,
    id_renglon integer NOT NULL,
    id_despacho integer NOT NULL,
    "manualSelection" boolean NOT NULL,
    cantidad integer NOT NULL,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL,
    observacion text DEFAULT 's/o'::text
);


ALTER TABLE public."Despachos_Renglones" OWNER TO postgres;

--
-- Name: Despachos_Renglones_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Despachos_Renglones_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Despachos_Renglones_id_seq" OWNER TO postgres;

--
-- Name: Despachos_Renglones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Despachos_Renglones_id_seq" OWNED BY public."Despachos_Renglones".id;


--
-- Name: Destinatario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Destinatario" (
    id integer NOT NULL,
    tipo_cedula public."Tipos_Cedulas" NOT NULL,
    cedula text NOT NULL,
    nombres text NOT NULL,
    apellidos text NOT NULL,
    telefono text NOT NULL,
    cargo_profesional text,
    direccion text NOT NULL,
    tipo public."Tipos_Destinatarios" NOT NULL,
    sexo public."Generos" NOT NULL,
    id_unidad integer,
    id_categoria integer,
    id_grado integer,
    id_componente integer,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL,
    servicio text
);


ALTER TABLE public."Destinatario" OWNER TO postgres;

--
-- Name: Destinatario_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Destinatario_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Destinatario_id_seq" OWNER TO postgres;

--
-- Name: Destinatario_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Destinatario_id_seq" OWNED BY public."Destinatario".id;


--
-- Name: Devolucion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Devolucion" (
    id integer NOT NULL,
    fecha_devolucion timestamp(3) without time zone NOT NULL,
    motivo text NOT NULL,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL,
    cedula_destinatario text NOT NULL,
    cedula_abastecedor text NOT NULL,
    cedula_autorizador text NOT NULL,
    cedula_supervisor text,
    servicio public."Servicios"
);


ALTER TABLE public."Devolucion" OWNER TO postgres;

--
-- Name: Devolucion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Devolucion_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Devolucion_id_seq" OWNER TO postgres;

--
-- Name: Devolucion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Devolucion_id_seq" OWNED BY public."Devolucion".id;


--
-- Name: Devoluciones_Renglones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Devoluciones_Renglones" (
    id integer NOT NULL,
    id_renglon integer NOT NULL,
    id_devolucion integer NOT NULL,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Devoluciones_Renglones" OWNER TO postgres;

--
-- Name: Devoluciones_Renglones_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Devoluciones_Renglones_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Devoluciones_Renglones_id_seq" OWNER TO postgres;

--
-- Name: Devoluciones_Renglones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Devoluciones_Renglones_id_seq" OWNED BY public."Devoluciones_Renglones".id;


--
-- Name: Grado_Militar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Grado_Militar" (
    id integer NOT NULL,
    nombre text NOT NULL,
    abreviatura text NOT NULL,
    orden integer,
    estado text,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Grado_Militar" OWNER TO postgres;

--
-- Name: Grado_Militar_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Grado_Militar_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Grado_Militar_id_seq" OWNER TO postgres;

--
-- Name: Grado_Militar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Grado_Militar_id_seq" OWNED BY public."Grado_Militar".id;


--
-- Name: Grados_Componentes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Grados_Componentes" (
    id integer NOT NULL,
    id_grado integer NOT NULL,
    id_componente integer NOT NULL,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Grados_Componentes" OWNER TO postgres;

--
-- Name: Grados_Componentes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Grados_Componentes_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Grados_Componentes_id_seq" OWNER TO postgres;

--
-- Name: Grados_Componentes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Grados_Componentes_id_seq" OWNED BY public."Grados_Componentes".id;


--
-- Name: Guardia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Guardia" (
    id integer NOT NULL,
    estado text NOT NULL,
    ubicacion text NOT NULL,
    fecha timestamp(3) without time zone NOT NULL,
    cedula_usuario text NOT NULL,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Guardia" OWNER TO postgres;

--
-- Name: Guardia_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Guardia_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Guardia_id_seq" OWNER TO postgres;

--
-- Name: Guardia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Guardia_id_seq" OWNED BY public."Guardia".id;


--
-- Name: Image; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Image" (
    id integer NOT NULL,
    image text NOT NULL
);


ALTER TABLE public."Image" OWNER TO postgres;

--
-- Name: Image_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Image_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Image_id_seq" OWNER TO postgres;

--
-- Name: Image_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Image_id_seq" OWNED BY public."Image".id;


--
-- Name: Marca_Armamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Marca_Armamento" (
    id integer NOT NULL,
    nombre text NOT NULL
);


ALTER TABLE public."Marca_Armamento" OWNER TO postgres;

--
-- Name: Marca_Armamento_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Marca_Armamento_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Marca_Armamento_id_seq" OWNER TO postgres;

--
-- Name: Marca_Armamento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Marca_Armamento_id_seq" OWNED BY public."Marca_Armamento".id;


--
-- Name: Modelo_Armamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Modelo_Armamento" (
    id integer NOT NULL,
    nombre text NOT NULL,
    id_marca integer NOT NULL,
    id_calibre integer NOT NULL,
    id_tipo_armamento integer NOT NULL
);


ALTER TABLE public."Modelo_Armamento" OWNER TO postgres;

--
-- Name: Modelo_Armamento_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Modelo_Armamento_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Modelo_Armamento_id_seq" OWNER TO postgres;

--
-- Name: Modelo_Armamento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Modelo_Armamento_id_seq" OWNED BY public."Modelo_Armamento".id;


--
-- Name: Parte_Arma; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Parte_Arma" (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text NOT NULL,
    id_modelo integer NOT NULL
);


ALTER TABLE public."Parte_Arma" OWNER TO postgres;

--
-- Name: Parte_Arma_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Parte_Arma_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Parte_Arma_id_seq" OWNER TO postgres;

--
-- Name: Parte_Arma_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Parte_Arma_id_seq" OWNED BY public."Parte_Arma".id;


--
-- Name: PasswordResetToken; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PasswordResetToken" (
    id text NOT NULL,
    email text NOT NULL,
    token text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PasswordResetToken" OWNER TO postgres;

--
-- Name: Pedido; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Pedido" (
    id integer NOT NULL,
    motivo text NOT NULL,
    id_proveedor integer,
    id_unidad integer,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL,
    estado public."Estados_Pedidos",
    fecha_solicitud timestamp(3) without time zone NOT NULL,
    id_abastecedor integer NOT NULL,
    id_autorizador integer NOT NULL,
    id_destinatario integer,
    id_supervisor integer,
    tipo_proveedor public."Tipos_Proveedores" NOT NULL,
    servicio public."Servicios"
);


ALTER TABLE public."Pedido" OWNER TO postgres;

--
-- Name: Pedido_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Pedido_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Pedido_id_seq" OWNER TO postgres;

--
-- Name: Pedido_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Pedido_id_seq" OWNED BY public."Pedido".id;


--
-- Name: Pedidos_Renglones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Pedidos_Renglones" (
    id integer NOT NULL,
    cantidad integer NOT NULL,
    id_renglon integer NOT NULL,
    id_pedido integer NOT NULL,
    observacion text DEFAULT 's/o'::text,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Pedidos_Renglones" OWNER TO postgres;

--
-- Name: Pedidos_Renglones_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Pedidos_Renglones_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Pedidos_Renglones_id_seq" OWNER TO postgres;

--
-- Name: Pedidos_Renglones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Pedidos_Renglones_id_seq" OWNED BY public."Pedidos_Renglones".id;


--
-- Name: Permiso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Permiso" (
    id integer NOT NULL,
    permiso text NOT NULL,
    descripcion text NOT NULL,
    key text NOT NULL
);


ALTER TABLE public."Permiso" OWNER TO postgres;

--
-- Name: Permiso_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Permiso_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Permiso_id_seq" OWNER TO postgres;

--
-- Name: Permiso_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Permiso_id_seq" OWNED BY public."Permiso".id;


--
-- Name: Personal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Personal" (
    id integer NOT NULL,
    tipo_cedula public."Tipos_Cedulas" NOT NULL,
    cedula text NOT NULL,
    nombres text NOT NULL,
    apellidos text NOT NULL,
    telefono text NOT NULL,
    cargo_profesional text,
    direccion text NOT NULL,
    tipo public."Tipos_Destinatarios" NOT NULL,
    sexo public."Generos" NOT NULL,
    id_unidad integer,
    id_categoria integer,
    id_grado integer,
    id_componente integer,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL,
    cedula_usuario text
);


ALTER TABLE public."Personal" OWNER TO postgres;

--
-- Name: Personal_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Personal_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Personal_id_seq" OWNER TO postgres;

--
-- Name: Personal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Personal_id_seq" OWNED BY public."Personal".id;


--
-- Name: Profesional_Abastecimiento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Profesional_Abastecimiento" (
    id integer NOT NULL,
    tipo_cedula public."Tipos_Cedulas" NOT NULL,
    cedula text NOT NULL,
    nombres text NOT NULL,
    apellidos text NOT NULL,
    telefono text NOT NULL,
    cargo_profesional text,
    direccion text NOT NULL,
    sexo public."Generos" NOT NULL,
    id_unidad integer,
    id_categoria integer NOT NULL,
    id_grado integer NOT NULL,
    id_componente integer NOT NULL,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Profesional_Abastecimiento" OWNER TO postgres;

--
-- Name: Profesional_Abastecimiento_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Profesional_Abastecimiento_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Profesional_Abastecimiento_id_seq" OWNER TO postgres;

--
-- Name: Profesional_Abastecimiento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Profesional_Abastecimiento_id_seq" OWNED BY public."Profesional_Abastecimiento".id;


--
-- Name: Proveedor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Proveedor" (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text,
    direccion text NOT NULL,
    sitio_web text,
    telefono text NOT NULL,
    telefono_secundario text,
    email text,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Proveedor" OWNER TO postgres;

--
-- Name: Proveedor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Proveedor_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Proveedor_id_seq" OWNER TO postgres;

--
-- Name: Proveedor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Proveedor_id_seq" OWNED BY public."Proveedor".id;


--
-- Name: Recepcion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Recepcion" (
    id integer NOT NULL,
    fecha_recepcion timestamp(3) without time zone NOT NULL,
    motivo text,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL,
    cedula_abastecedor text NOT NULL,
    cedula_autorizador text NOT NULL,
    cedula_destinatario text NOT NULL,
    cedula_supervisor text,
    servicio public."Servicios"
);


ALTER TABLE public."Recepcion" OWNER TO postgres;

--
-- Name: Recepcion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Recepcion_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Recepcion_id_seq" OWNER TO postgres;

--
-- Name: Recepcion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Recepcion_id_seq" OWNED BY public."Recepcion".id;


--
-- Name: Recepciones_Renglones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Recepciones_Renglones" (
    id integer NOT NULL,
    id_recepcion integer NOT NULL,
    id_renglon integer NOT NULL,
    cantidad integer NOT NULL,
    seriales_automaticos boolean NOT NULL,
    fabricante text,
    precio double precision,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL,
    fecha_fabricacion timestamp(3) without time zone,
    fecha_vencimiento timestamp(3) without time zone,
    observacion text DEFAULT 's/o'::text,
    codigo_solicitud integer
);


ALTER TABLE public."Recepciones_Renglones" OWNER TO postgres;

--
-- Name: Recepciones_Renglones_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Recepciones_Renglones_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Recepciones_Renglones_id_seq" OWNER TO postgres;

--
-- Name: Recepciones_Renglones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Recepciones_Renglones_id_seq" OWNED BY public."Recepciones_Renglones".id;


--
-- Name: Redi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Redi" (
    nombre text NOT NULL,
    descripcion text NOT NULL,
    ubicacion text NOT NULL,
    id integer NOT NULL
);


ALTER TABLE public."Redi" OWNER TO postgres;

--
-- Name: Redi_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Redi_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Redi_id_seq" OWNER TO postgres;

--
-- Name: Redi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Redi_id_seq" OWNED BY public."Redi".id;


--
-- Name: Renglon; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Renglon" (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text NOT NULL,
    tipo text,
    stock_minimo integer DEFAULT 1 NOT NULL,
    stock_maximo integer,
    numero_parte text,
    peso double precision DEFAULT 1 NOT NULL,
    estado public."RenglonStates" DEFAULT 'Activo'::public."RenglonStates",
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL,
    "unidadEmpaqueId" integer NOT NULL,
    "clasificacionId" integer NOT NULL,
    "categoriaId" integer NOT NULL,
    id_subsistema integer,
    id_almacen integer,
    imagen text,
    servicio public."Servicios"
);


ALTER TABLE public."Renglon" OWNER TO postgres;

--
-- Name: Renglon_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Renglon_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Renglon_id_seq" OWNER TO postgres;

--
-- Name: Renglon_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Renglon_id_seq" OWNED BY public."Renglon".id;


--
-- Name: Rol; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Rol" (
    id integer NOT NULL,
    rol text NOT NULL,
    descripcion text NOT NULL
);


ALTER TABLE public."Rol" OWNER TO postgres;

--
-- Name: Rol_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Rol_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Rol_id_seq" OWNER TO postgres;

--
-- Name: Rol_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Rol_id_seq" OWNED BY public."Rol".id;


--
-- Name: Roles_Permisos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Roles_Permisos" (
    id integer NOT NULL,
    rol_nombre text NOT NULL,
    permiso_key text NOT NULL,
    active boolean
);


ALTER TABLE public."Roles_Permisos" OWNER TO postgres;

--
-- Name: Roles_Permisos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Roles_Permisos_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Roles_Permisos_id_seq" OWNER TO postgres;

--
-- Name: Roles_Permisos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Roles_Permisos_id_seq" OWNED BY public."Roles_Permisos".id;


--
-- Name: Serial; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Serial" (
    id integer NOT NULL,
    serial text NOT NULL,
    id_renglon integer NOT NULL,
    id_recepcion integer NOT NULL,
    estado text DEFAULT 'Disponible'::text,
    id_despacho integer,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL,
    id_devolucion integer
);


ALTER TABLE public."Serial" OWNER TO postgres;

--
-- Name: Serial_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Serial_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Serial_id_seq" OWNER TO postgres;

--
-- Name: Serial_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Serial_id_seq" OWNED BY public."Serial".id;


--
-- Name: Session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "sessionToken" text NOT NULL,
    "userId" text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Session" OWNER TO postgres;

--
-- Name: Sistema; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Sistema" (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text NOT NULL,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Sistema" OWNER TO postgres;

--
-- Name: Sistema_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Sistema_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Sistema_id_seq" OWNER TO postgres;

--
-- Name: Sistema_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Sistema_id_seq" OWNED BY public."Sistema".id;


--
-- Name: Subsistema; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Subsistema" (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text NOT NULL,
    id_sistema integer NOT NULL,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Subsistema" OWNER TO postgres;

--
-- Name: Subsistema_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Subsistema_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Subsistema_id_seq" OWNER TO postgres;

--
-- Name: Subsistema_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Subsistema_id_seq" OWNED BY public."Subsistema".id;


--
-- Name: Tipo_Armamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Tipo_Armamento" (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text NOT NULL
);


ALTER TABLE public."Tipo_Armamento" OWNER TO postgres;

--
-- Name: Tipo_Armamento_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Tipo_Armamento_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Tipo_Armamento_id_seq" OWNER TO postgres;

--
-- Name: Tipo_Armamento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Tipo_Armamento_id_seq" OWNED BY public."Tipo_Armamento".id;


--
-- Name: UnidadEmpaque; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."UnidadEmpaque" (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text NOT NULL,
    abreviacion text,
    tipo_medida public."Medidas" NOT NULL,
    peso double precision,
    id_categoria integer NOT NULL,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."UnidadEmpaque" OWNER TO postgres;

--
-- Name: UnidadEmpaque_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."UnidadEmpaque_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."UnidadEmpaque_id_seq" OWNER TO postgres;

--
-- Name: UnidadEmpaque_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."UnidadEmpaque_id_seq" OWNED BY public."UnidadEmpaque".id;


--
-- Name: Unidad_Militar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Unidad_Militar" (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text NOT NULL,
    ubicacion text NOT NULL,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultima_actualizacion timestamp(3) without time zone NOT NULL,
    id_zodi integer NOT NULL
);


ALTER TABLE public."Unidad_Militar" OWNER TO postgres;

--
-- Name: Unidad_Militar_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Unidad_Militar_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Unidad_Militar_id_seq" OWNER TO postgres;

--
-- Name: Unidad_Militar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Unidad_Militar_id_seq" OWNED BY public."Unidad_Militar".id;


--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id text NOT NULL,
    nombre text NOT NULL,
    email text,
    password text,
    "facialID" text,
    "emailVerified" timestamp(3) without time zone,
    image text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    rol_nombre text DEFAULT 'Basico'::text NOT NULL,
    cedula text NOT NULL,
    tipo_cedula public."Tipos_Cedulas",
    estado public."Usuarios_Estados"
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: VerificationToken; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."VerificationToken" (
    identifier text NOT NULL,
    token text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."VerificationToken" OWNER TO postgres;

--
-- Name: Zodi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Zodi" (
    nombre text NOT NULL,
    descripcion text NOT NULL,
    ubicacion text NOT NULL,
    id integer NOT NULL,
    id_redi integer NOT NULL
);


ALTER TABLE public."Zodi" OWNER TO postgres;

--
-- Name: Zodi_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Zodi_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Zodi_id_seq" OWNER TO postgres;

--
-- Name: Zodi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Zodi_id_seq" OWNED BY public."Zodi".id;


--
-- Name: reposos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reposos (
    id text NOT NULL
);


ALTER TABLE public.reposos OWNER TO postgres;

--
-- Name: Accesorio_Arma id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Accesorio_Arma" ALTER COLUMN id SET DEFAULT nextval('public."Accesorio_Arma_id_seq"'::regclass);


--
-- Name: Admin id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Admin" ALTER COLUMN id SET DEFAULT nextval('public."Admin_id_seq"'::regclass);


--
-- Name: Almacen id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Almacen" ALTER COLUMN id SET DEFAULT nextval('public."Almacen_id_seq"'::regclass);


--
-- Name: Armamento id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Armamento" ALTER COLUMN id SET DEFAULT nextval('public."Armamento_id_seq"'::regclass);


--
-- Name: Asistencia id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Asistencia" ALTER COLUMN id SET DEFAULT nextval('public."Asistencia_id_seq"'::regclass);


--
-- Name: AttendanceCredentials id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AttendanceCredentials" ALTER COLUMN id SET DEFAULT nextval('public."AttendanceCredentials_id_seq"'::regclass);


--
-- Name: Auditoria id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Auditoria" ALTER COLUMN id SET DEFAULT nextval('public."Auditoria_id_seq"'::regclass);


--
-- Name: Calibre id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Calibre" ALTER COLUMN id SET DEFAULT nextval('public."Calibre_id_seq"'::regclass);


--
-- Name: Categoria id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Categoria" ALTER COLUMN id SET DEFAULT nextval('public."Categoria_id_seq"'::regclass);


--
-- Name: Categoria_Militar id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Categoria_Militar" ALTER COLUMN id SET DEFAULT nextval('public."Categoria_Militar_id_seq"'::regclass);


--
-- Name: Categorias_Grados id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Categorias_Grados" ALTER COLUMN id SET DEFAULT nextval('public."Categorias_Grados_id_seq"'::regclass);


--
-- Name: Clasificacion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Clasificacion" ALTER COLUMN id SET DEFAULT nextval('public."Clasificacion_id_seq"'::regclass);


--
-- Name: Componente_Arma id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Componente_Arma" ALTER COLUMN id SET DEFAULT nextval('public."Componente_Arma_id_seq"'::regclass);


--
-- Name: Componente_Militar id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Componente_Militar" ALTER COLUMN id SET DEFAULT nextval('public."Componente_Militar_id_seq"'::regclass);


--
-- Name: Despacho id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Despacho" ALTER COLUMN id SET DEFAULT nextval('public."Despacho_id_seq"'::regclass);


--
-- Name: Despachos_Renglones id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Despachos_Renglones" ALTER COLUMN id SET DEFAULT nextval('public."Despachos_Renglones_id_seq"'::regclass);


--
-- Name: Destinatario id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Destinatario" ALTER COLUMN id SET DEFAULT nextval('public."Destinatario_id_seq"'::regclass);


--
-- Name: Devolucion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Devolucion" ALTER COLUMN id SET DEFAULT nextval('public."Devolucion_id_seq"'::regclass);


--
-- Name: Devoluciones_Renglones id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Devoluciones_Renglones" ALTER COLUMN id SET DEFAULT nextval('public."Devoluciones_Renglones_id_seq"'::regclass);


--
-- Name: Grado_Militar id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Grado_Militar" ALTER COLUMN id SET DEFAULT nextval('public."Grado_Militar_id_seq"'::regclass);


--
-- Name: Grados_Componentes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Grados_Componentes" ALTER COLUMN id SET DEFAULT nextval('public."Grados_Componentes_id_seq"'::regclass);


--
-- Name: Guardia id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Guardia" ALTER COLUMN id SET DEFAULT nextval('public."Guardia_id_seq"'::regclass);


--
-- Name: Image id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Image" ALTER COLUMN id SET DEFAULT nextval('public."Image_id_seq"'::regclass);


--
-- Name: Marca_Armamento id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Marca_Armamento" ALTER COLUMN id SET DEFAULT nextval('public."Marca_Armamento_id_seq"'::regclass);


--
-- Name: Modelo_Armamento id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Modelo_Armamento" ALTER COLUMN id SET DEFAULT nextval('public."Modelo_Armamento_id_seq"'::regclass);


--
-- Name: Parte_Arma id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parte_Arma" ALTER COLUMN id SET DEFAULT nextval('public."Parte_Arma_id_seq"'::regclass);


--
-- Name: Pedido id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Pedido" ALTER COLUMN id SET DEFAULT nextval('public."Pedido_id_seq"'::regclass);


--
-- Name: Pedidos_Renglones id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Pedidos_Renglones" ALTER COLUMN id SET DEFAULT nextval('public."Pedidos_Renglones_id_seq"'::regclass);


--
-- Name: Permiso id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Permiso" ALTER COLUMN id SET DEFAULT nextval('public."Permiso_id_seq"'::regclass);


--
-- Name: Personal id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Personal" ALTER COLUMN id SET DEFAULT nextval('public."Personal_id_seq"'::regclass);


--
-- Name: Profesional_Abastecimiento id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Profesional_Abastecimiento" ALTER COLUMN id SET DEFAULT nextval('public."Profesional_Abastecimiento_id_seq"'::regclass);


--
-- Name: Proveedor id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Proveedor" ALTER COLUMN id SET DEFAULT nextval('public."Proveedor_id_seq"'::regclass);


--
-- Name: Recepcion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recepcion" ALTER COLUMN id SET DEFAULT nextval('public."Recepcion_id_seq"'::regclass);


--
-- Name: Recepciones_Renglones id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recepciones_Renglones" ALTER COLUMN id SET DEFAULT nextval('public."Recepciones_Renglones_id_seq"'::regclass);


--
-- Name: Redi id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Redi" ALTER COLUMN id SET DEFAULT nextval('public."Redi_id_seq"'::regclass);


--
-- Name: Renglon id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Renglon" ALTER COLUMN id SET DEFAULT nextval('public."Renglon_id_seq"'::regclass);


--
-- Name: Rol id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Rol" ALTER COLUMN id SET DEFAULT nextval('public."Rol_id_seq"'::regclass);


--
-- Name: Roles_Permisos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Roles_Permisos" ALTER COLUMN id SET DEFAULT nextval('public."Roles_Permisos_id_seq"'::regclass);


--
-- Name: Serial id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Serial" ALTER COLUMN id SET DEFAULT nextval('public."Serial_id_seq"'::regclass);


--
-- Name: Sistema id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sistema" ALTER COLUMN id SET DEFAULT nextval('public."Sistema_id_seq"'::regclass);


--
-- Name: Subsistema id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Subsistema" ALTER COLUMN id SET DEFAULT nextval('public."Subsistema_id_seq"'::regclass);


--
-- Name: Tipo_Armamento id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Tipo_Armamento" ALTER COLUMN id SET DEFAULT nextval('public."Tipo_Armamento_id_seq"'::regclass);


--
-- Name: UnidadEmpaque id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UnidadEmpaque" ALTER COLUMN id SET DEFAULT nextval('public."UnidadEmpaque_id_seq"'::regclass);


--
-- Name: Unidad_Militar id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Unidad_Militar" ALTER COLUMN id SET DEFAULT nextval('public."Unidad_Militar_id_seq"'::regclass);


--
-- Name: Zodi id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Zodi" ALTER COLUMN id SET DEFAULT nextval('public."Zodi_id_seq"'::regclass);


--
-- Data for Name: Accesorio_Arma; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Accesorio_Arma" (id, nombre, descripcion, id_modelo) FROM stdin;
\.
COPY public."Accesorio_Arma" (id, nombre, descripcion, id_modelo) FROM '$$PATH$$/5401.dat';

--
-- Data for Name: Account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Account" (id, "userId", type, provider, "providerAccountId", refresh_token, access_token, expires_at, token_type, scope, id_token, session_state) FROM stdin;
\.
COPY public."Account" (id, "userId", type, provider, "providerAccountId", refresh_token, access_token, expires_at, token_type, scope, id_token, session_state) FROM '$$PATH$$/5403.dat';

--
-- Data for Name: Admin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Admin" (id, password, state, fecha_creacion, ultima_actualizacion) FROM stdin;
\.
COPY public."Admin" (id, password, state, fecha_creacion, ultima_actualizacion) FROM '$$PATH$$/5404.dat';

--
-- Data for Name: Almacen; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Almacen" (id, nombre, ubicacion, fecha_creacion, ultima_actualizacion, id_unidad, servicio) FROM stdin;
\.
COPY public."Almacen" (id, nombre, ubicacion, fecha_creacion, ultima_actualizacion, id_unidad, servicio) FROM '$$PATH$$/5406.dat';

--
-- Data for Name: Armamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Armamento" (descripcion, id, serial_armazon, serial_canon, fecha_fabricacion, lugar_fabricacion, numero_causa, id_unidad, id_almacen, pasillo, id_modelo, color, condicion, estado) FROM stdin;
\.
COPY public."Armamento" (descripcion, id, serial_armazon, serial_canon, fecha_fabricacion, lugar_fabricacion, numero_causa, id_unidad, id_almacen, pasillo, id_modelo, color, condicion, estado) FROM '$$PATH$$/5408.dat';

--
-- Data for Name: Asistencia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Asistencia" (id, id_usuario, fecha_realizado, hora_entrada, hora_salida) FROM stdin;
\.
COPY public."Asistencia" (id, id_usuario, fecha_realizado, hora_entrada, hora_salida) FROM '$$PATH$$/5410.dat';

--
-- Data for Name: AttendanceCredentials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AttendanceCredentials" (id, show_credentials) FROM stdin;
\.
COPY public."AttendanceCredentials" (id, show_credentials) FROM '$$PATH$$/5412.dat';

--
-- Data for Name: Auditoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Auditoria" (id, id_usuario, accion, fecha_realizado, ultima_actualizacion) FROM stdin;
\.
COPY public."Auditoria" (id, id_usuario, accion, fecha_realizado, ultima_actualizacion) FROM '$$PATH$$/5414.dat';

--
-- Data for Name: Calibre; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Calibre" (id, nombre, descripcion) FROM stdin;
\.
COPY public."Calibre" (id, nombre, descripcion) FROM '$$PATH$$/5416.dat';

--
-- Data for Name: Categoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Categoria" (id, nombre, descripcion, id_clasificacion, fecha_creacion, ultima_actualizacion) FROM stdin;
\.
COPY public."Categoria" (id, nombre, descripcion, id_clasificacion, fecha_creacion, ultima_actualizacion) FROM '$$PATH$$/5418.dat';

--
-- Data for Name: Categoria_Militar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Categoria_Militar" (id, nombre, abreviatura, estado, fecha_creacion, ultima_actualizacion) FROM stdin;
\.
COPY public."Categoria_Militar" (id, nombre, abreviatura, estado, fecha_creacion, ultima_actualizacion) FROM '$$PATH$$/5419.dat';

--
-- Data for Name: Categorias_Grados; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Categorias_Grados" (id, id_categoria, fecha_creacion, ultima_actualizacion, id_grado) FROM stdin;
\.
COPY public."Categorias_Grados" (id, id_categoria, fecha_creacion, ultima_actualizacion, id_grado) FROM '$$PATH$$/5422.dat';

--
-- Data for Name: Clasificacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Clasificacion" (id, nombre, descripcion, fecha_creacion, ultima_actualizacion) FROM stdin;
\.
COPY public."Clasificacion" (id, nombre, descripcion, fecha_creacion, ultima_actualizacion) FROM '$$PATH$$/5424.dat';

--
-- Data for Name: Componente_Arma; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Componente_Arma" (id, nombre, descripcion, id_modelo) FROM stdin;
\.
COPY public."Componente_Arma" (id, nombre, descripcion, id_modelo) FROM '$$PATH$$/5426.dat';

--
-- Data for Name: Componente_Militar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Componente_Militar" (id, nombre, descripcion, estado, fecha_creacion, ultima_actualizacion) FROM stdin;
\.
COPY public."Componente_Militar" (id, nombre, descripcion, estado, fecha_creacion, ultima_actualizacion) FROM '$$PATH$$/5428.dat';

--
-- Data for Name: Despacho; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Despacho" (id, fecha_despacho, motivo, cedula_destinatario, fecha_creacion, ultima_actualizacion, cedula_abastecedor, cedula_autorizador, cedula_supervisor, servicio) FROM stdin;
\.
COPY public."Despacho" (id, fecha_despacho, motivo, cedula_destinatario, fecha_creacion, ultima_actualizacion, cedula_abastecedor, cedula_autorizador, cedula_supervisor, servicio) FROM '$$PATH$$/5430.dat';

--
-- Data for Name: Despachos_Renglones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Despachos_Renglones" (id, id_renglon, id_despacho, "manualSelection", cantidad, fecha_creacion, ultima_actualizacion, observacion) FROM stdin;
\.
COPY public."Despachos_Renglones" (id, id_renglon, id_despacho, "manualSelection", cantidad, fecha_creacion, ultima_actualizacion, observacion) FROM '$$PATH$$/5432.dat';

--
-- Data for Name: Destinatario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Destinatario" (id, tipo_cedula, cedula, nombres, apellidos, telefono, cargo_profesional, direccion, tipo, sexo, id_unidad, id_categoria, id_grado, id_componente, fecha_creacion, ultima_actualizacion, servicio) FROM stdin;
\.
COPY public."Destinatario" (id, tipo_cedula, cedula, nombres, apellidos, telefono, cargo_profesional, direccion, tipo, sexo, id_unidad, id_categoria, id_grado, id_componente, fecha_creacion, ultima_actualizacion, servicio) FROM '$$PATH$$/5434.dat';

--
-- Data for Name: Devolucion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Devolucion" (id, fecha_devolucion, motivo, fecha_creacion, ultima_actualizacion, cedula_destinatario, cedula_abastecedor, cedula_autorizador, cedula_supervisor, servicio) FROM stdin;
\.
COPY public."Devolucion" (id, fecha_devolucion, motivo, fecha_creacion, ultima_actualizacion, cedula_destinatario, cedula_abastecedor, cedula_autorizador, cedula_supervisor, servicio) FROM '$$PATH$$/5436.dat';

--
-- Data for Name: Devoluciones_Renglones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Devoluciones_Renglones" (id, id_renglon, id_devolucion, fecha_creacion, ultima_actualizacion) FROM stdin;
\.
COPY public."Devoluciones_Renglones" (id, id_renglon, id_devolucion, fecha_creacion, ultima_actualizacion) FROM '$$PATH$$/5438.dat';

--
-- Data for Name: Grado_Militar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Grado_Militar" (id, nombre, abreviatura, orden, estado, fecha_creacion, ultima_actualizacion) FROM stdin;
\.
COPY public."Grado_Militar" (id, nombre, abreviatura, orden, estado, fecha_creacion, ultima_actualizacion) FROM '$$PATH$$/5440.dat';

--
-- Data for Name: Grados_Componentes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Grados_Componentes" (id, id_grado, id_componente, fecha_creacion, ultima_actualizacion) FROM stdin;
\.
COPY public."Grados_Componentes" (id, id_grado, id_componente, fecha_creacion, ultima_actualizacion) FROM '$$PATH$$/5442.dat';

--
-- Data for Name: Guardia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Guardia" (id, estado, ubicacion, fecha, cedula_usuario, fecha_creacion, ultima_actualizacion) FROM stdin;
\.
COPY public."Guardia" (id, estado, ubicacion, fecha, cedula_usuario, fecha_creacion, ultima_actualizacion) FROM '$$PATH$$/5444.dat';

--
-- Data for Name: Image; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Image" (id, image) FROM stdin;
\.
COPY public."Image" (id, image) FROM '$$PATH$$/5446.dat';

--
-- Data for Name: Marca_Armamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Marca_Armamento" (id, nombre) FROM stdin;
\.
COPY public."Marca_Armamento" (id, nombre) FROM '$$PATH$$/5448.dat';

--
-- Data for Name: Modelo_Armamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Modelo_Armamento" (id, nombre, id_marca, id_calibre, id_tipo_armamento) FROM stdin;
\.
COPY public."Modelo_Armamento" (id, nombre, id_marca, id_calibre, id_tipo_armamento) FROM '$$PATH$$/5450.dat';

--
-- Data for Name: Parte_Arma; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Parte_Arma" (id, nombre, descripcion, id_modelo) FROM stdin;
\.
COPY public."Parte_Arma" (id, nombre, descripcion, id_modelo) FROM '$$PATH$$/5452.dat';

--
-- Data for Name: PasswordResetToken; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PasswordResetToken" (id, email, token, expires) FROM stdin;
\.
COPY public."PasswordResetToken" (id, email, token, expires) FROM '$$PATH$$/5454.dat';

--
-- Data for Name: Pedido; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Pedido" (id, motivo, id_proveedor, id_unidad, fecha_creacion, ultima_actualizacion, estado, fecha_solicitud, id_abastecedor, id_autorizador, id_destinatario, id_supervisor, tipo_proveedor, servicio) FROM stdin;
\.
COPY public."Pedido" (id, motivo, id_proveedor, id_unidad, fecha_creacion, ultima_actualizacion, estado, fecha_solicitud, id_abastecedor, id_autorizador, id_destinatario, id_supervisor, tipo_proveedor, servicio) FROM '$$PATH$$/5455.dat';

--
-- Data for Name: Pedidos_Renglones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Pedidos_Renglones" (id, cantidad, id_renglon, id_pedido, observacion, fecha_creacion, ultima_actualizacion) FROM stdin;
\.
COPY public."Pedidos_Renglones" (id, cantidad, id_renglon, id_pedido, observacion, fecha_creacion, ultima_actualizacion) FROM '$$PATH$$/5457.dat';

--
-- Data for Name: Permiso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Permiso" (id, permiso, descripcion, key) FROM stdin;
\.
COPY public."Permiso" (id, permiso, descripcion, key) FROM '$$PATH$$/5459.dat';

--
-- Data for Name: Personal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Personal" (id, tipo_cedula, cedula, nombres, apellidos, telefono, cargo_profesional, direccion, tipo, sexo, id_unidad, id_categoria, id_grado, id_componente, fecha_creacion, ultima_actualizacion, cedula_usuario) FROM stdin;
\.
COPY public."Personal" (id, tipo_cedula, cedula, nombres, apellidos, telefono, cargo_profesional, direccion, tipo, sexo, id_unidad, id_categoria, id_grado, id_componente, fecha_creacion, ultima_actualizacion, cedula_usuario) FROM '$$PATH$$/5461.dat';

--
-- Data for Name: Profesional_Abastecimiento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Profesional_Abastecimiento" (id, tipo_cedula, cedula, nombres, apellidos, telefono, cargo_profesional, direccion, sexo, id_unidad, id_categoria, id_grado, id_componente, fecha_creacion, ultima_actualizacion) FROM stdin;
\.
COPY public."Profesional_Abastecimiento" (id, tipo_cedula, cedula, nombres, apellidos, telefono, cargo_profesional, direccion, sexo, id_unidad, id_categoria, id_grado, id_componente, fecha_creacion, ultima_actualizacion) FROM '$$PATH$$/5463.dat';

--
-- Data for Name: Proveedor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Proveedor" (id, nombre, descripcion, direccion, sitio_web, telefono, telefono_secundario, email, fecha_creacion, ultima_actualizacion) FROM stdin;
\.
COPY public."Proveedor" (id, nombre, descripcion, direccion, sitio_web, telefono, telefono_secundario, email, fecha_creacion, ultima_actualizacion) FROM '$$PATH$$/5465.dat';

--
-- Data for Name: Recepcion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Recepcion" (id, fecha_recepcion, motivo, fecha_creacion, ultima_actualizacion, cedula_abastecedor, cedula_autorizador, cedula_destinatario, cedula_supervisor, servicio) FROM stdin;
\.
COPY public."Recepcion" (id, fecha_recepcion, motivo, fecha_creacion, ultima_actualizacion, cedula_abastecedor, cedula_autorizador, cedula_destinatario, cedula_supervisor, servicio) FROM '$$PATH$$/5467.dat';

--
-- Data for Name: Recepciones_Renglones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Recepciones_Renglones" (id, id_recepcion, id_renglon, cantidad, seriales_automaticos, fabricante, precio, fecha_creacion, ultima_actualizacion, fecha_fabricacion, fecha_vencimiento, observacion, codigo_solicitud) FROM stdin;
\.
COPY public."Recepciones_Renglones" (id, id_recepcion, id_renglon, cantidad, seriales_automaticos, fabricante, precio, fecha_creacion, ultima_actualizacion, fecha_fabricacion, fecha_vencimiento, observacion, codigo_solicitud) FROM '$$PATH$$/5469.dat';

--
-- Data for Name: Redi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Redi" (nombre, descripcion, ubicacion, id) FROM stdin;
\.
COPY public."Redi" (nombre, descripcion, ubicacion, id) FROM '$$PATH$$/5471.dat';

--
-- Data for Name: Renglon; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Renglon" (id, nombre, descripcion, tipo, stock_minimo, stock_maximo, numero_parte, peso, estado, fecha_creacion, ultima_actualizacion, "unidadEmpaqueId", "clasificacionId", "categoriaId", id_subsistema, id_almacen, imagen, servicio) FROM stdin;
\.
COPY public."Renglon" (id, nombre, descripcion, tipo, stock_minimo, stock_maximo, numero_parte, peso, estado, fecha_creacion, ultima_actualizacion, "unidadEmpaqueId", "clasificacionId", "categoriaId", id_subsistema, id_almacen, imagen, servicio) FROM '$$PATH$$/5473.dat';

--
-- Data for Name: Rol; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Rol" (id, rol, descripcion) FROM stdin;
\.
COPY public."Rol" (id, rol, descripcion) FROM '$$PATH$$/5475.dat';

--
-- Data for Name: Roles_Permisos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Roles_Permisos" (id, rol_nombre, permiso_key, active) FROM stdin;
\.
COPY public."Roles_Permisos" (id, rol_nombre, permiso_key, active) FROM '$$PATH$$/5477.dat';

--
-- Data for Name: Serial; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Serial" (id, serial, id_renglon, id_recepcion, estado, id_despacho, fecha_creacion, ultima_actualizacion, id_devolucion) FROM stdin;
\.
COPY public."Serial" (id, serial, id_renglon, id_recepcion, estado, id_despacho, fecha_creacion, ultima_actualizacion, id_devolucion) FROM '$$PATH$$/5479.dat';

--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Session" (id, "sessionToken", "userId", expires) FROM stdin;
\.
COPY public."Session" (id, "sessionToken", "userId", expires) FROM '$$PATH$$/5481.dat';

--
-- Data for Name: Sistema; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Sistema" (id, nombre, descripcion, fecha_creacion, ultima_actualizacion) FROM stdin;
\.
COPY public."Sistema" (id, nombre, descripcion, fecha_creacion, ultima_actualizacion) FROM '$$PATH$$/5482.dat';

--
-- Data for Name: Subsistema; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Subsistema" (id, nombre, descripcion, id_sistema, fecha_creacion, ultima_actualizacion) FROM stdin;
\.
COPY public."Subsistema" (id, nombre, descripcion, id_sistema, fecha_creacion, ultima_actualizacion) FROM '$$PATH$$/5484.dat';

--
-- Data for Name: Tipo_Armamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Tipo_Armamento" (id, nombre, descripcion) FROM stdin;
\.
COPY public."Tipo_Armamento" (id, nombre, descripcion) FROM '$$PATH$$/5486.dat';

--
-- Data for Name: UnidadEmpaque; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."UnidadEmpaque" (id, nombre, descripcion, abreviacion, tipo_medida, peso, id_categoria, fecha_creacion, ultima_actualizacion) FROM stdin;
\.
COPY public."UnidadEmpaque" (id, nombre, descripcion, abreviacion, tipo_medida, peso, id_categoria, fecha_creacion, ultima_actualizacion) FROM '$$PATH$$/5488.dat';

--
-- Data for Name: Unidad_Militar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Unidad_Militar" (id, nombre, descripcion, ubicacion, fecha_creacion, ultima_actualizacion, id_zodi) FROM stdin;
\.
COPY public."Unidad_Militar" (id, nombre, descripcion, ubicacion, fecha_creacion, ultima_actualizacion, id_zodi) FROM '$$PATH$$/5490.dat';

--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, nombre, email, password, "facialID", "emailVerified", image, "createdAt", "updatedAt", rol_nombre, cedula, tipo_cedula, estado) FROM stdin;
\.
COPY public."User" (id, nombre, email, password, "facialID", "emailVerified", image, "createdAt", "updatedAt", rol_nombre, cedula, tipo_cedula, estado) FROM '$$PATH$$/5492.dat';

--
-- Data for Name: VerificationToken; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."VerificationToken" (identifier, token, expires) FROM stdin;
\.
COPY public."VerificationToken" (identifier, token, expires) FROM '$$PATH$$/5493.dat';

--
-- Data for Name: Zodi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Zodi" (nombre, descripcion, ubicacion, id, id_redi) FROM stdin;
\.
COPY public."Zodi" (nombre, descripcion, ubicacion, id, id_redi) FROM '$$PATH$$/5494.dat';

--
-- Data for Name: reposos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reposos (id) FROM stdin;
\.
COPY public.reposos (id) FROM '$$PATH$$/5496.dat';

--
-- Name: Accesorio_Arma_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Accesorio_Arma_id_seq"', 6, true);


--
-- Name: Admin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Admin_id_seq"', 2, true);


--
-- Name: Almacen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Almacen_id_seq"', 5, true);


--
-- Name: Armamento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Armamento_id_seq"', 8, true);


--
-- Name: Asistencia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Asistencia_id_seq"', 33, true);


--
-- Name: AttendanceCredentials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AttendanceCredentials_id_seq"', 1, true);


--
-- Name: Auditoria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Auditoria_id_seq"', 569, true);


--
-- Name: Calibre_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Calibre_id_seq"', 14, true);


--
-- Name: Categoria_Militar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Categoria_Militar_id_seq"', 5, true);


--
-- Name: Categoria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Categoria_id_seq"', 11, true);


--
-- Name: Categorias_Grados_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Categorias_Grados_id_seq"', 51, true);


--
-- Name: Clasificacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Clasificacion_id_seq"', 6, true);


--
-- Name: Componente_Arma_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Componente_Arma_id_seq"', 1, false);


--
-- Name: Componente_Militar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Componente_Militar_id_seq"', 7, true);


--
-- Name: Despacho_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Despacho_id_seq"', 38, true);


--
-- Name: Despachos_Renglones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Despachos_Renglones_id_seq"', 72, true);


--
-- Name: Destinatario_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Destinatario_id_seq"', 9, true);


--
-- Name: Devolucion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Devolucion_id_seq"', 13, true);


--
-- Name: Devoluciones_Renglones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Devoluciones_Renglones_id_seq"', 21, true);


--
-- Name: Grado_Militar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Grado_Militar_id_seq"', 27, true);


--
-- Name: Grados_Componentes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Grados_Componentes_id_seq"', 86, true);


--
-- Name: Guardia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Guardia_id_seq"', 15, true);


--
-- Name: Image_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Image_id_seq"', 1, true);


--
-- Name: Marca_Armamento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Marca_Armamento_id_seq"', 4, true);


--
-- Name: Modelo_Armamento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Modelo_Armamento_id_seq"', 7, true);


--
-- Name: Parte_Arma_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Parte_Arma_id_seq"', 11, true);


--
-- Name: Pedido_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Pedido_id_seq"', 10, true);


--
-- Name: Pedidos_Renglones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Pedidos_Renglones_id_seq"', 36, true);


--
-- Name: Permiso_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Permiso_id_seq"', 10, true);


--
-- Name: Personal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Personal_id_seq"', 12, true);


--
-- Name: Profesional_Abastecimiento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Profesional_Abastecimiento_id_seq"', 6, true);


--
-- Name: Proveedor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Proveedor_id_seq"', 4, true);


--
-- Name: Recepcion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Recepcion_id_seq"', 28, true);


--
-- Name: Recepciones_Renglones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Recepciones_Renglones_id_seq"', 63, true);


--
-- Name: Redi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Redi_id_seq"', 2, true);


--
-- Name: Renglon_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Renglon_id_seq"', 50, true);


--
-- Name: Rol_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Rol_id_seq"', 9, true);


--
-- Name: Roles_Permisos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Roles_Permisos_id_seq"', 36, true);


--
-- Name: Serial_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Serial_id_seq"', 979, true);


--
-- Name: Sistema_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Sistema_id_seq"', 3, true);


--
-- Name: Subsistema_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Subsistema_id_seq"', 4, true);


--
-- Name: Tipo_Armamento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Tipo_Armamento_id_seq"', 6, true);


--
-- Name: UnidadEmpaque_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."UnidadEmpaque_id_seq"', 6, true);


--
-- Name: Unidad_Militar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Unidad_Militar_id_seq"', 6, true);


--
-- Name: Zodi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Zodi_id_seq"', 3, true);


--
-- Name: Accesorio_Arma Accesorio_Arma_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Accesorio_Arma"
    ADD CONSTRAINT "Accesorio_Arma_pkey" PRIMARY KEY (id);


--
-- Name: Account Account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_pkey" PRIMARY KEY (id);


--
-- Name: Admin Admin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Admin"
    ADD CONSTRAINT "Admin_pkey" PRIMARY KEY (id);


--
-- Name: Almacen Almacen_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Almacen"
    ADD CONSTRAINT "Almacen_pkey" PRIMARY KEY (id);


--
-- Name: Armamento Armamento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Armamento"
    ADD CONSTRAINT "Armamento_pkey" PRIMARY KEY (id);


--
-- Name: Asistencia Asistencia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Asistencia"
    ADD CONSTRAINT "Asistencia_pkey" PRIMARY KEY (id);


--
-- Name: AttendanceCredentials AttendanceCredentials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AttendanceCredentials"
    ADD CONSTRAINT "AttendanceCredentials_pkey" PRIMARY KEY (id);


--
-- Name: Auditoria Auditoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Auditoria"
    ADD CONSTRAINT "Auditoria_pkey" PRIMARY KEY (id);


--
-- Name: Calibre Calibre_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Calibre"
    ADD CONSTRAINT "Calibre_pkey" PRIMARY KEY (id);


--
-- Name: Categoria_Militar Categoria_Militar_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Categoria_Militar"
    ADD CONSTRAINT "Categoria_Militar_pkey" PRIMARY KEY (id);


--
-- Name: Categoria Categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Categoria"
    ADD CONSTRAINT "Categoria_pkey" PRIMARY KEY (id);


--
-- Name: Categorias_Grados Categorias_Grados_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Categorias_Grados"
    ADD CONSTRAINT "Categorias_Grados_pkey" PRIMARY KEY (id);


--
-- Name: Clasificacion Clasificacion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Clasificacion"
    ADD CONSTRAINT "Clasificacion_pkey" PRIMARY KEY (id);


--
-- Name: Componente_Arma Componente_Arma_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Componente_Arma"
    ADD CONSTRAINT "Componente_Arma_pkey" PRIMARY KEY (id);


--
-- Name: Componente_Militar Componente_Militar_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Componente_Militar"
    ADD CONSTRAINT "Componente_Militar_pkey" PRIMARY KEY (id);


--
-- Name: Despacho Despacho_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Despacho"
    ADD CONSTRAINT "Despacho_pkey" PRIMARY KEY (id);


--
-- Name: Despachos_Renglones Despachos_Renglones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Despachos_Renglones"
    ADD CONSTRAINT "Despachos_Renglones_pkey" PRIMARY KEY (id);


--
-- Name: Destinatario Destinatario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Destinatario"
    ADD CONSTRAINT "Destinatario_pkey" PRIMARY KEY (id);


--
-- Name: Devolucion Devolucion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Devolucion"
    ADD CONSTRAINT "Devolucion_pkey" PRIMARY KEY (id);


--
-- Name: Devoluciones_Renglones Devoluciones_Renglones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Devoluciones_Renglones"
    ADD CONSTRAINT "Devoluciones_Renglones_pkey" PRIMARY KEY (id);


--
-- Name: Grado_Militar Grado_Militar_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Grado_Militar"
    ADD CONSTRAINT "Grado_Militar_pkey" PRIMARY KEY (id);


--
-- Name: Grados_Componentes Grados_Componentes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Grados_Componentes"
    ADD CONSTRAINT "Grados_Componentes_pkey" PRIMARY KEY (id);


--
-- Name: Guardia Guardia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Guardia"
    ADD CONSTRAINT "Guardia_pkey" PRIMARY KEY (id);


--
-- Name: Image Image_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Image"
    ADD CONSTRAINT "Image_pkey" PRIMARY KEY (id);


--
-- Name: Marca_Armamento Marca_Armamento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Marca_Armamento"
    ADD CONSTRAINT "Marca_Armamento_pkey" PRIMARY KEY (id);


--
-- Name: Modelo_Armamento Modelo_Armamento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Modelo_Armamento"
    ADD CONSTRAINT "Modelo_Armamento_pkey" PRIMARY KEY (id);


--
-- Name: Parte_Arma Parte_Arma_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parte_Arma"
    ADD CONSTRAINT "Parte_Arma_pkey" PRIMARY KEY (id);


--
-- Name: PasswordResetToken PasswordResetToken_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_pkey" PRIMARY KEY (id);


--
-- Name: Pedido Pedido_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Pedido"
    ADD CONSTRAINT "Pedido_pkey" PRIMARY KEY (id);


--
-- Name: Pedidos_Renglones Pedidos_Renglones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Pedidos_Renglones"
    ADD CONSTRAINT "Pedidos_Renglones_pkey" PRIMARY KEY (id);


--
-- Name: Permiso Permiso_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Permiso"
    ADD CONSTRAINT "Permiso_pkey" PRIMARY KEY (id);


--
-- Name: Personal Personal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Personal"
    ADD CONSTRAINT "Personal_pkey" PRIMARY KEY (id);


--
-- Name: Profesional_Abastecimiento Profesional_Abastecimiento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Profesional_Abastecimiento"
    ADD CONSTRAINT "Profesional_Abastecimiento_pkey" PRIMARY KEY (id);


--
-- Name: Proveedor Proveedor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Proveedor"
    ADD CONSTRAINT "Proveedor_pkey" PRIMARY KEY (id);


--
-- Name: Recepcion Recepcion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recepcion"
    ADD CONSTRAINT "Recepcion_pkey" PRIMARY KEY (id);


--
-- Name: Recepciones_Renglones Recepciones_Renglones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recepciones_Renglones"
    ADD CONSTRAINT "Recepciones_Renglones_pkey" PRIMARY KEY (id);


--
-- Name: Redi Redi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Redi"
    ADD CONSTRAINT "Redi_pkey" PRIMARY KEY (id);


--
-- Name: Renglon Renglon_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Renglon"
    ADD CONSTRAINT "Renglon_pkey" PRIMARY KEY (id);


--
-- Name: Rol Rol_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Rol"
    ADD CONSTRAINT "Rol_pkey" PRIMARY KEY (id);


--
-- Name: Roles_Permisos Roles_Permisos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Roles_Permisos"
    ADD CONSTRAINT "Roles_Permisos_pkey" PRIMARY KEY (id);


--
-- Name: Serial Serial_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Serial"
    ADD CONSTRAINT "Serial_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: Sistema Sistema_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sistema"
    ADD CONSTRAINT "Sistema_pkey" PRIMARY KEY (id);


--
-- Name: Subsistema Subsistema_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Subsistema"
    ADD CONSTRAINT "Subsistema_pkey" PRIMARY KEY (id);


--
-- Name: Tipo_Armamento Tipo_Armamento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Tipo_Armamento"
    ADD CONSTRAINT "Tipo_Armamento_pkey" PRIMARY KEY (id);


--
-- Name: UnidadEmpaque UnidadEmpaque_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UnidadEmpaque"
    ADD CONSTRAINT "UnidadEmpaque_pkey" PRIMARY KEY (id);


--
-- Name: Unidad_Militar Unidad_Militar_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Unidad_Militar"
    ADD CONSTRAINT "Unidad_Militar_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Zodi Zodi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Zodi"
    ADD CONSTRAINT "Zodi_pkey" PRIMARY KEY (id);


--
-- Name: reposos reposos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposos
    ADD CONSTRAINT reposos_pkey PRIMARY KEY (id);


--
-- Name: Account_provider_providerAccountId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Account_provider_providerAccountId_key" ON public."Account" USING btree (provider, "providerAccountId");


--
-- Name: Categoria_Militar_nombre_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Categoria_Militar_nombre_key" ON public."Categoria_Militar" USING btree (nombre);


--
-- Name: Categoria_nombre_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Categoria_nombre_key" ON public."Categoria" USING btree (nombre);


--
-- Name: Clasificacion_nombre_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Clasificacion_nombre_key" ON public."Clasificacion" USING btree (nombre);


--
-- Name: Componente_Militar_nombre_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Componente_Militar_nombre_key" ON public."Componente_Militar" USING btree (nombre);


--
-- Name: Destinatario_cedula_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Destinatario_cedula_key" ON public."Destinatario" USING btree (cedula);


--
-- Name: Grado_Militar_nombre_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Grado_Militar_nombre_key" ON public."Grado_Militar" USING btree (nombre);


--
-- Name: PasswordResetToken_email_token_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PasswordResetToken_email_token_key" ON public."PasswordResetToken" USING btree (email, token);


--
-- Name: PasswordResetToken_token_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PasswordResetToken_token_key" ON public."PasswordResetToken" USING btree (token);


--
-- Name: Permiso_key_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Permiso_key_key" ON public."Permiso" USING btree (key);


--
-- Name: Personal_cedula_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Personal_cedula_key" ON public."Personal" USING btree (cedula);


--
-- Name: Personal_cedula_usuario_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Personal_cedula_usuario_key" ON public."Personal" USING btree (cedula_usuario);


--
-- Name: Profesional_Abastecimiento_cedula_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Profesional_Abastecimiento_cedula_key" ON public."Profesional_Abastecimiento" USING btree (cedula);


--
-- Name: Redi_nombre_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Redi_nombre_key" ON public."Redi" USING btree (nombre);


--
-- Name: Renglon_nombre_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Renglon_nombre_key" ON public."Renglon" USING btree (nombre);


--
-- Name: Rol_rol_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Rol_rol_key" ON public."Rol" USING btree (rol);


--
-- Name: Serial_serial_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Serial_serial_key" ON public."Serial" USING btree (serial);


--
-- Name: Session_sessionToken_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Session_sessionToken_key" ON public."Session" USING btree ("sessionToken");


--
-- Name: UnidadEmpaque_nombre_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UnidadEmpaque_nombre_key" ON public."UnidadEmpaque" USING btree (nombre);


--
-- Name: Unidad_Militar_nombre_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Unidad_Militar_nombre_key" ON public."Unidad_Militar" USING btree (nombre);


--
-- Name: User_cedula_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_cedula_key" ON public."User" USING btree (cedula);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_facialID_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_facialID_key" ON public."User" USING btree ("facialID");


--
-- Name: VerificationToken_identifier_token_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "VerificationToken_identifier_token_key" ON public."VerificationToken" USING btree (identifier, token);


--
-- Name: VerificationToken_token_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "VerificationToken_token_key" ON public."VerificationToken" USING btree (token);


--
-- Name: Zodi_nombre_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Zodi_nombre_key" ON public."Zodi" USING btree (nombre);


--
-- Name: Accesorio_Arma Accesorio_Arma_id_modelo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Accesorio_Arma"
    ADD CONSTRAINT "Accesorio_Arma_id_modelo_fkey" FOREIGN KEY (id_modelo) REFERENCES public."Modelo_Armamento"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Account Account_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Almacen Almacen_id_unidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Almacen"
    ADD CONSTRAINT "Almacen_id_unidad_fkey" FOREIGN KEY (id_unidad) REFERENCES public."Unidad_Militar"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Armamento Armamento_id_almacen_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Armamento"
    ADD CONSTRAINT "Armamento_id_almacen_fkey" FOREIGN KEY (id_almacen) REFERENCES public."Almacen"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Armamento Armamento_id_modelo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Armamento"
    ADD CONSTRAINT "Armamento_id_modelo_fkey" FOREIGN KEY (id_modelo) REFERENCES public."Modelo_Armamento"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Armamento Armamento_id_unidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Armamento"
    ADD CONSTRAINT "Armamento_id_unidad_fkey" FOREIGN KEY (id_unidad) REFERENCES public."Unidad_Militar"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Asistencia Asistencia_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Asistencia"
    ADD CONSTRAINT "Asistencia_id_usuario_fkey" FOREIGN KEY (id_usuario) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Auditoria Auditoria_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Auditoria"
    ADD CONSTRAINT "Auditoria_id_usuario_fkey" FOREIGN KEY (id_usuario) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Categoria Categoria_id_clasificacion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Categoria"
    ADD CONSTRAINT "Categoria_id_clasificacion_fkey" FOREIGN KEY (id_clasificacion) REFERENCES public."Clasificacion"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Categorias_Grados Categorias_Grados_id_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Categorias_Grados"
    ADD CONSTRAINT "Categorias_Grados_id_categoria_fkey" FOREIGN KEY (id_categoria) REFERENCES public."Categoria_Militar"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Categorias_Grados Categorias_Grados_id_grado_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Categorias_Grados"
    ADD CONSTRAINT "Categorias_Grados_id_grado_fkey" FOREIGN KEY (id_grado) REFERENCES public."Grado_Militar"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Componente_Arma Componente_Arma_id_modelo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Componente_Arma"
    ADD CONSTRAINT "Componente_Arma_id_modelo_fkey" FOREIGN KEY (id_modelo) REFERENCES public."Modelo_Armamento"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Despacho Despacho_cedula_abastecedor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Despacho"
    ADD CONSTRAINT "Despacho_cedula_abastecedor_fkey" FOREIGN KEY (cedula_abastecedor) REFERENCES public."Profesional_Abastecimiento"(cedula) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Despacho Despacho_cedula_autorizador_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Despacho"
    ADD CONSTRAINT "Despacho_cedula_autorizador_fkey" FOREIGN KEY (cedula_autorizador) REFERENCES public."Profesional_Abastecimiento"(cedula) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Despacho Despacho_cedula_destinatario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Despacho"
    ADD CONSTRAINT "Despacho_cedula_destinatario_fkey" FOREIGN KEY (cedula_destinatario) REFERENCES public."Destinatario"(cedula) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Despacho Despacho_cedula_supervisor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Despacho"
    ADD CONSTRAINT "Despacho_cedula_supervisor_fkey" FOREIGN KEY (cedula_supervisor) REFERENCES public."Profesional_Abastecimiento"(cedula) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Despachos_Renglones Despachos_Renglones_id_despacho_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Despachos_Renglones"
    ADD CONSTRAINT "Despachos_Renglones_id_despacho_fkey" FOREIGN KEY (id_despacho) REFERENCES public."Despacho"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Despachos_Renglones Despachos_Renglones_id_renglon_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Despachos_Renglones"
    ADD CONSTRAINT "Despachos_Renglones_id_renglon_fkey" FOREIGN KEY (id_renglon) REFERENCES public."Renglon"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Destinatario Destinatario_id_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Destinatario"
    ADD CONSTRAINT "Destinatario_id_categoria_fkey" FOREIGN KEY (id_categoria) REFERENCES public."Categoria_Militar"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Destinatario Destinatario_id_componente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Destinatario"
    ADD CONSTRAINT "Destinatario_id_componente_fkey" FOREIGN KEY (id_componente) REFERENCES public."Componente_Militar"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Destinatario Destinatario_id_grado_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Destinatario"
    ADD CONSTRAINT "Destinatario_id_grado_fkey" FOREIGN KEY (id_grado) REFERENCES public."Grado_Militar"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Destinatario Destinatario_id_unidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Destinatario"
    ADD CONSTRAINT "Destinatario_id_unidad_fkey" FOREIGN KEY (id_unidad) REFERENCES public."Unidad_Militar"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Devolucion Devolucion_cedula_abastecedor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Devolucion"
    ADD CONSTRAINT "Devolucion_cedula_abastecedor_fkey" FOREIGN KEY (cedula_abastecedor) REFERENCES public."Profesional_Abastecimiento"(cedula) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Devolucion Devolucion_cedula_autorizador_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Devolucion"
    ADD CONSTRAINT "Devolucion_cedula_autorizador_fkey" FOREIGN KEY (cedula_autorizador) REFERENCES public."Profesional_Abastecimiento"(cedula) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Devolucion Devolucion_cedula_destinatario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Devolucion"
    ADD CONSTRAINT "Devolucion_cedula_destinatario_fkey" FOREIGN KEY (cedula_destinatario) REFERENCES public."Destinatario"(cedula) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Devolucion Devolucion_cedula_supervisor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Devolucion"
    ADD CONSTRAINT "Devolucion_cedula_supervisor_fkey" FOREIGN KEY (cedula_supervisor) REFERENCES public."Profesional_Abastecimiento"(cedula) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Devoluciones_Renglones Devoluciones_Renglones_id_devolucion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Devoluciones_Renglones"
    ADD CONSTRAINT "Devoluciones_Renglones_id_devolucion_fkey" FOREIGN KEY (id_devolucion) REFERENCES public."Devolucion"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Devoluciones_Renglones Devoluciones_Renglones_id_renglon_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Devoluciones_Renglones"
    ADD CONSTRAINT "Devoluciones_Renglones_id_renglon_fkey" FOREIGN KEY (id_renglon) REFERENCES public."Renglon"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Grados_Componentes Grados_Componentes_id_componente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Grados_Componentes"
    ADD CONSTRAINT "Grados_Componentes_id_componente_fkey" FOREIGN KEY (id_componente) REFERENCES public."Componente_Militar"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Grados_Componentes Grados_Componentes_id_grado_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Grados_Componentes"
    ADD CONSTRAINT "Grados_Componentes_id_grado_fkey" FOREIGN KEY (id_grado) REFERENCES public."Grado_Militar"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Guardia Guardia_cedula_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Guardia"
    ADD CONSTRAINT "Guardia_cedula_usuario_fkey" FOREIGN KEY (cedula_usuario) REFERENCES public."Personal"(cedula) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Modelo_Armamento Modelo_Armamento_id_calibre_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Modelo_Armamento"
    ADD CONSTRAINT "Modelo_Armamento_id_calibre_fkey" FOREIGN KEY (id_calibre) REFERENCES public."Calibre"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Modelo_Armamento Modelo_Armamento_id_marca_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Modelo_Armamento"
    ADD CONSTRAINT "Modelo_Armamento_id_marca_fkey" FOREIGN KEY (id_marca) REFERENCES public."Marca_Armamento"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Modelo_Armamento Modelo_Armamento_id_tipo_armamento_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Modelo_Armamento"
    ADD CONSTRAINT "Modelo_Armamento_id_tipo_armamento_fkey" FOREIGN KEY (id_tipo_armamento) REFERENCES public."Tipo_Armamento"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Parte_Arma Parte_Arma_id_modelo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parte_Arma"
    ADD CONSTRAINT "Parte_Arma_id_modelo_fkey" FOREIGN KEY (id_modelo) REFERENCES public."Modelo_Armamento"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Pedido Pedido_id_abastecedor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Pedido"
    ADD CONSTRAINT "Pedido_id_abastecedor_fkey" FOREIGN KEY (id_abastecedor) REFERENCES public."Profesional_Abastecimiento"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Pedido Pedido_id_autorizador_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Pedido"
    ADD CONSTRAINT "Pedido_id_autorizador_fkey" FOREIGN KEY (id_autorizador) REFERENCES public."Profesional_Abastecimiento"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Pedido Pedido_id_destinatario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Pedido"
    ADD CONSTRAINT "Pedido_id_destinatario_fkey" FOREIGN KEY (id_destinatario) REFERENCES public."Destinatario"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Pedido Pedido_id_proveedor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Pedido"
    ADD CONSTRAINT "Pedido_id_proveedor_fkey" FOREIGN KEY (id_proveedor) REFERENCES public."Proveedor"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Pedido Pedido_id_supervisor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Pedido"
    ADD CONSTRAINT "Pedido_id_supervisor_fkey" FOREIGN KEY (id_supervisor) REFERENCES public."Profesional_Abastecimiento"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Pedido Pedido_id_unidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Pedido"
    ADD CONSTRAINT "Pedido_id_unidad_fkey" FOREIGN KEY (id_unidad) REFERENCES public."Unidad_Militar"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Pedidos_Renglones Pedidos_Renglones_id_pedido_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Pedidos_Renglones"
    ADD CONSTRAINT "Pedidos_Renglones_id_pedido_fkey" FOREIGN KEY (id_pedido) REFERENCES public."Pedido"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Pedidos_Renglones Pedidos_Renglones_id_renglon_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Pedidos_Renglones"
    ADD CONSTRAINT "Pedidos_Renglones_id_renglon_fkey" FOREIGN KEY (id_renglon) REFERENCES public."Renglon"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Personal Personal_cedula_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Personal"
    ADD CONSTRAINT "Personal_cedula_usuario_fkey" FOREIGN KEY (cedula_usuario) REFERENCES public."User"(cedula) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Personal Personal_id_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Personal"
    ADD CONSTRAINT "Personal_id_categoria_fkey" FOREIGN KEY (id_categoria) REFERENCES public."Categoria_Militar"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Personal Personal_id_componente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Personal"
    ADD CONSTRAINT "Personal_id_componente_fkey" FOREIGN KEY (id_componente) REFERENCES public."Componente_Militar"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Personal Personal_id_grado_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Personal"
    ADD CONSTRAINT "Personal_id_grado_fkey" FOREIGN KEY (id_grado) REFERENCES public."Grado_Militar"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Personal Personal_id_unidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Personal"
    ADD CONSTRAINT "Personal_id_unidad_fkey" FOREIGN KEY (id_unidad) REFERENCES public."Unidad_Militar"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Profesional_Abastecimiento Profesional_Abastecimiento_id_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Profesional_Abastecimiento"
    ADD CONSTRAINT "Profesional_Abastecimiento_id_categoria_fkey" FOREIGN KEY (id_categoria) REFERENCES public."Categoria_Militar"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Profesional_Abastecimiento Profesional_Abastecimiento_id_componente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Profesional_Abastecimiento"
    ADD CONSTRAINT "Profesional_Abastecimiento_id_componente_fkey" FOREIGN KEY (id_componente) REFERENCES public."Componente_Militar"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Profesional_Abastecimiento Profesional_Abastecimiento_id_grado_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Profesional_Abastecimiento"
    ADD CONSTRAINT "Profesional_Abastecimiento_id_grado_fkey" FOREIGN KEY (id_grado) REFERENCES public."Grado_Militar"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Profesional_Abastecimiento Profesional_Abastecimiento_id_unidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Profesional_Abastecimiento"
    ADD CONSTRAINT "Profesional_Abastecimiento_id_unidad_fkey" FOREIGN KEY (id_unidad) REFERENCES public."Unidad_Militar"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Recepcion Recepcion_cedula_abastecedor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recepcion"
    ADD CONSTRAINT "Recepcion_cedula_abastecedor_fkey" FOREIGN KEY (cedula_abastecedor) REFERENCES public."Profesional_Abastecimiento"(cedula) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Recepcion Recepcion_cedula_autorizador_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recepcion"
    ADD CONSTRAINT "Recepcion_cedula_autorizador_fkey" FOREIGN KEY (cedula_autorizador) REFERENCES public."Profesional_Abastecimiento"(cedula) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Recepcion Recepcion_cedula_destinatario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recepcion"
    ADD CONSTRAINT "Recepcion_cedula_destinatario_fkey" FOREIGN KEY (cedula_destinatario) REFERENCES public."Destinatario"(cedula) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Recepcion Recepcion_cedula_supervisor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recepcion"
    ADD CONSTRAINT "Recepcion_cedula_supervisor_fkey" FOREIGN KEY (cedula_supervisor) REFERENCES public."Profesional_Abastecimiento"(cedula) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Recepciones_Renglones Recepciones_Renglones_codigo_solicitud_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recepciones_Renglones"
    ADD CONSTRAINT "Recepciones_Renglones_codigo_solicitud_fkey" FOREIGN KEY (codigo_solicitud) REFERENCES public."Pedido"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Recepciones_Renglones Recepciones_Renglones_id_recepcion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recepciones_Renglones"
    ADD CONSTRAINT "Recepciones_Renglones_id_recepcion_fkey" FOREIGN KEY (id_recepcion) REFERENCES public."Recepcion"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Recepciones_Renglones Recepciones_Renglones_id_renglon_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recepciones_Renglones"
    ADD CONSTRAINT "Recepciones_Renglones_id_renglon_fkey" FOREIGN KEY (id_renglon) REFERENCES public."Renglon"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Renglon Renglon_categoriaId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Renglon"
    ADD CONSTRAINT "Renglon_categoriaId_fkey" FOREIGN KEY ("categoriaId") REFERENCES public."Categoria"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Renglon Renglon_clasificacionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Renglon"
    ADD CONSTRAINT "Renglon_clasificacionId_fkey" FOREIGN KEY ("clasificacionId") REFERENCES public."Clasificacion"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Renglon Renglon_id_almacen_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Renglon"
    ADD CONSTRAINT "Renglon_id_almacen_fkey" FOREIGN KEY (id_almacen) REFERENCES public."Almacen"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Renglon Renglon_id_subsistema_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Renglon"
    ADD CONSTRAINT "Renglon_id_subsistema_fkey" FOREIGN KEY (id_subsistema) REFERENCES public."Subsistema"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Renglon Renglon_unidadEmpaqueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Renglon"
    ADD CONSTRAINT "Renglon_unidadEmpaqueId_fkey" FOREIGN KEY ("unidadEmpaqueId") REFERENCES public."UnidadEmpaque"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Roles_Permisos Roles_Permisos_permiso_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Roles_Permisos"
    ADD CONSTRAINT "Roles_Permisos_permiso_key_fkey" FOREIGN KEY (permiso_key) REFERENCES public."Permiso"(key) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Roles_Permisos Roles_Permisos_rol_nombre_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Roles_Permisos"
    ADD CONSTRAINT "Roles_Permisos_rol_nombre_fkey" FOREIGN KEY (rol_nombre) REFERENCES public."Rol"(rol) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Serial Serial_id_despacho_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Serial"
    ADD CONSTRAINT "Serial_id_despacho_fkey" FOREIGN KEY (id_despacho) REFERENCES public."Despachos_Renglones"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Serial Serial_id_devolucion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Serial"
    ADD CONSTRAINT "Serial_id_devolucion_fkey" FOREIGN KEY (id_devolucion) REFERENCES public."Devoluciones_Renglones"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Serial Serial_id_recepcion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Serial"
    ADD CONSTRAINT "Serial_id_recepcion_fkey" FOREIGN KEY (id_recepcion) REFERENCES public."Recepciones_Renglones"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Serial Serial_id_renglon_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Serial"
    ADD CONSTRAINT "Serial_id_renglon_fkey" FOREIGN KEY (id_renglon) REFERENCES public."Renglon"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Subsistema Subsistema_id_sistema_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Subsistema"
    ADD CONSTRAINT "Subsistema_id_sistema_fkey" FOREIGN KEY (id_sistema) REFERENCES public."Sistema"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UnidadEmpaque UnidadEmpaque_id_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UnidadEmpaque"
    ADD CONSTRAINT "UnidadEmpaque_id_categoria_fkey" FOREIGN KEY (id_categoria) REFERENCES public."Categoria"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Unidad_Militar Unidad_Militar_id_zodi_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Unidad_Militar"
    ADD CONSTRAINT "Unidad_Militar_id_zodi_fkey" FOREIGN KEY (id_zodi) REFERENCES public."Zodi"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: User User_rol_nombre_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_rol_nombre_fkey" FOREIGN KEY (rol_nombre) REFERENCES public."Rol"(rol) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Zodi Zodi_id_redi_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Zodi"
    ADD CONSTRAINT "Zodi_id_redi_fkey" FOREIGN KEY (id_redi) REFERENCES public."Redi"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

